<template>
  <div id="app">
    <loading-bare v-show="show"></loading-bare>
    <router-view v-show="!show"></router-view>
  </div>
</template>

<script>
import LoadingBare from "./components/LoadingBare.vue";
export default {
  name: "App",
  data: () => {
    return {
      show: true,
    };
  },
  components: {
    LoadingBare,
  },
 mounted(){
  this.ShowLoader()
 },
  methods: {
    ShowLoader() {
      setTimeout(() => {
        this.show = false;
      }, 2300);
    },
  },
};
</script>

<style>
#app {
  font-family: "Roboto", sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

body {
  margin: 0px;
  padding: 0px;
  box-sizing: border-box;
}
</style>
