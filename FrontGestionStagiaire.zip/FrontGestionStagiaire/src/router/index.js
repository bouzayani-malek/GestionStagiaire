import Vue from 'vue'
import VueRouter from 'vue-router'

import Login from '../views/Login.vue'
import dashboard from '../views/Dashboard'
import Stage from '../views/Utilisateurs.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '',
    name: 'Login',
    component: Login,
  },

  {
    path: '/home',
    component: dashboard,
    children: [
      {
        path: 'dashbord',
        component: Stage,
        name: 'dashbord',
      },
      {
        path: 'stages',
        component: () =>
          import(/* webpackChunkName: "Messages" */ '../views/Stages.vue'),
        name: 'stages',
      },
      {
        path: 'stagiaires',
        component: () =>
          import(/* webpackChunkName: "Profile" */ '../views/Stagiaire.vue'),
        name: 'stagiaires',
      },
     
    ],
  },
  {
    path: '/DemandeStagiaire/code=:id',
    component: () =>
      import(/* webpackChunkName: "Settings" */ '../views/Demande.vue'),
      name:'DemandeStagiaire'
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
})

export default router
