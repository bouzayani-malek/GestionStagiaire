<template>
  <div class="container">
    <p></p>

    <div class="row">
      <div class="col">
        <!--menu users-->

        <nav
          class="navbar navbar-light"
          style="background-color: #9a9a9a; box-shadow: 0.1px 53px #9a9a9a"
        >
          <div class="container-fluid">
            <a class="navbar-brand log" >{{role.role1}}</a>
            <button type="button" class="btn btn-warning rounded-circle"   @click="malek()">
              <i class="bi bi-power"></i>
            </button>
          </div>
        </nav>
      </div>
    </div>

    <!--fin menu users-->

    <p></p>
    <loading-bare v-show="show"></loading-bare>
    <div class="container">
      <div class="row">
        <!--liste stage-->

        <liste-stage
          :stages="Stages"
          @edit-stage="EditStage"
          @ajout-stage="ajout"
          @affecter-stage="affecter"
          v-show="!affiche && !edit && !show1"
        ></liste-stage>
        <!--fin liste stage-->

        <!--ajouter stage-->
        <ajout-stage v-show="affiche" @retour="Retour"></ajout-stage>
        <affecter-stage
          v-show="show1"
          @retour="Retour"
          :idstage="idstage"
          :utilisateurAfecter="Afecter"
          :Listeutilisateur="Listeutilisateur"
          @affecterUser="affecteruser"
        ></affecter-stage>

        <!--fin ajouter-->
      </div>
    </div>
    <br />
    <edit-stage :editstage="Stage" v-show="edit" @retour="Retour"></edit-stage>
  </div>
</template>

<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from "axios";
import ListeStage from "../components/ListeStage.vue";
import AjoutStage from "../components/AjoutStage.vue";
import EditStage from "../components/EditStage.vue";
import LoadingBare from "../components/LoadingBare.vue";
import AffecterStage from "../components/AffecterStage.vue";
export default {
  name: "Stage",
  components: {
    AjoutStage,
    ListeStage,
    EditStage,
    LoadingBare,
    AffecterStage,
  },
  data: () => {
    return {
      Stages: "",
      Stage: "",
      affiche: false,
      edit: false,
      show: true,
      show1: false,
      idstage: "",
      utilisateurAfecter: "",
      Afecter: "",
      Listeutilisateur: "",
         role:"",
    };
  },
  async created() {
    //get role
    this.role=(await axios.get("http://localhost:3000/api/Roles/"+localStorage.getItem('role'),{
      headers:{
        Authorization:'Bearer ' + localStorage.getItem('token')
      }
    }))
      .data;
    this.Stages = (
      await axios.get("http://localhost:3000/api/Stages", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
    ).data;
    this.utilisateurAfecter = (
      await axios.get("http://localhost:3000/api/Satgeutilisateurs", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
    ).data;
    this.Listeutilisateur = (
      await axios.get("http://localhost:3000/api/Utilisateurs", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
    ).data;
  },
  mounted() {
    this.ShowLoade();
  },
  methods: {
      deconnection(){
      this.$router.push({ name: "Login" });
    },
       malek() {
      swal
        .fire({
          title: "Deconnecté ?",
          text: "",
          icon: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-warning",
          confirmButtonText: "Yes, Deconnecté !",
        })
        .then((result) => {
          if (result.isConfirmed) {
           this.deconnection();
          }
        });
    },
    ShowLoade() {
      setTimeout(() => {
        this.show = false;
      }, 400);
    },
    ajout(e) {
      this.affiche = e;
    },
    affecter(e, idstage) {
      this.show1 = e;
      this.idstage = idstage;

      this.Afecter = this.utilisateurAfecter.filter(
        (u) => u.idStage == idstage
      );
    },
    Retour(e) {
      this.affiche = e;
      this.edit = false;
      this.show1 = e;
    },
    EditStage(e) {
      this.Stage = e;
      this.edit = true;
    },
  },
};
</script>
<style >
@import url("https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css");
.navbar {
  background-color: #9a9a9a;
  box-shadow: 0.1px 53px #9a9a9a;
}

.btn:hover {
  color: #fff;
}

.input-text:focus {
  box-shadow: 0px 0px 0px;
  border-color: #f8c146;
  outline: 0px;
}

.form-control {
  border: 1px solid #f8c146;
}
</style>