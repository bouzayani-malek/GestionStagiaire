<template>
  <div class="container content" style="margin-top: 30px" v-if="Stage.etat==1">
    <div class="row">
      <div class="col-md-12" style="padding: 40px">
        <div class="row justify-content-center">
          <div class="col-md-6">
            <h1 class="header-titl">{{ Stage.titre }}</h1>
            <br />
            <div style="font-size: 30px" class="mt-2" v-html="Stage.description"></div>
            <p>
              <img
                :src="require(`../assets/${Stage.image}`)"
                class="img-fluid mt-4"
              />
            </p>
            <p style="font-size: 30px" class="mt-4">
              Nombre de Stagiaire : {{ Stage.nombreStagiaire }} 
            </p>
          </div>
   
          <div class="col-md-6" style="margin-top: 40px">
            <form
              class="mb-5"
              method="post"
              id="contactForm"
              name="contactForm"
            >
              <div class="row">
                <div class="col-md-12 form-group">
                  <label for="name" class="label">Nom : </label>

                  <input
                    type="text"
                    class="form-control"
                    name="name"
                    id="name"
                    placeholder="nom"
                    v-model="nom"
                  />
                </div>
              </div>
              <div class="row mt-2">
                <div class="col-md-12 form-group">
                  <label for="prenom" class="label">Prenom : </label>

                  <input
                    type="text"
                    class="form-control"
                    name="prenom"
                    id="prenom"
                    placeholder="prenom"
                    v-model="prenom"
                  />
                </div>
              </div>
              <div class="row mt-2">
                <div class="col-md-12 form-group">
                  <label for="email" class="label">Email : </label>
                  <input
                    type="text"
                    class="form-control"
                    name="email"
                    id="email"
                    placeholder="Email"
                    v-model="email"
                  />
                </div>
              </div>
              <div class="row mt-2">
                <div class="col-md-12 form-group">
                  <label for="cv" class="label">Cv : </label>
                  <input
                    type="text"
                    class="form-control"
                    name="cv"
                    v-model="cv"
                  />
                </div>
              </div>

              <div class="row mt-4">
                <div class="col-12">
                  <button
                    style="border-radius: 20px; font-size: 20px"
                    type="button"
                    class="btn btn-warning"
                    @click="Notification()"
                  >
                    ajouter
                  </button>
                  <span class="submitting"></span>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div v-else class="content container" style="margin-top: 200px">
    <div class="justify-content-center header-title">Not Found</div>
  </div>
</template>
<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from "axios";
export default {
  name: "Demande",
  data: () => {
    return {
      Stage: "",
      nom: "",
      prenom: "",
      email: "",
      cv: "",
    };
  },
  async created() {
    this.Stage = (
      await axios.get(
        "http://localhost:3000/api/stages/DemandeStagiaire?code=" +
          this.$route.params.id
      )
    ).data.validUser;
  },
  methods: {
    ajouterStagiaire() {
      const stagiaire = {
        nom : this.nom,
        prenom: this.prenom,
        email: this.email,
        cv: this.cv,
        idEtatStagiare: 1,
        idStage: this.Stage.idStage,
      };
       axios
        .post("http://localhost:3000/api/Stagiaires/DemandeStagiaire", stagiaire)
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
         this.nom= "",
      this.prenom ="",
      this.email= "",
      this.cv= ""
    },
    Notification() {
      this.ajouterStagiaire();
      swal.fire("Ajouter!", "Your donation has been Ajouter.", "success");
    },
  },
};
</script>
<style>
.header-titl {
  font-family: cursive;
  font-size: 50px;
  text-align: center;

  color: #888888;
}
.label {
  font-family: cursive;
  font-size: 35px;
  text-align: center;

  color: #888888;
}

.form-control {
  font-family: cursive;
  border-radius: 50px;
  font-size: 25px;
  text-align: center;
  border-color: orange;
}

.login-form .form-group {
  position: relative;
}

.login-form .form-group .forgot-password {
  position: absolute;
  top: 15px;
  right: 15px;
}

.login-form .btn {
  border-radius: 100px;
  margin-bottom: 50px;
}

.login-form .btn.btn-primary {
  background: orange;
  border-color: orange;
}
</style>