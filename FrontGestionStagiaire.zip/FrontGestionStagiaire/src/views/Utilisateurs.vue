<template>
  <div class="container">
    <p></p>

    <div class="row">
      <div class="col">
        <!--menu users-->

        <nav
          class="navbar navbar-light"
          style="background-color: #9a9a9a; box-shadow: 0.1px 53px #9a9a9a"
        >
          <div class="container-fluid">
            <a class="navbar-brand log" >{{role.role1}}</a>
            <button
              type="button"
              class="btn btn-warning rounded-circle"
              @click="malek()"
            >
              <i class="bi bi-power"></i>
            </button>
          </div>
        </nav>
      </div>
    </div>

    <!--fin menu users-->

    <p></p>
    <loading-bare v-show="show"></loading-bare>
    <div class="container" v-show="!show">
      <!--liste users-->
      <div class="row">
        <liste-user
          :ListeAdmin="Administrateurs"
          :ListeUtilisateur="Utilisateurs"
          :active="active_el"
          @affiche-utilisateur="detail"
          @Affiche-edit="edit"
        ></liste-user>

        <!--fin liste users-->
        <!--detaille users-->
        <detail-user :det="details" v-show="affiche"></detail-user>
        <edit-user :edit="x" v-show="!affiche"></edit-user>
        <!--fin detaile users-->
      </div>
    </div>
    <br />
   
    <!--ajouter users-->

    <ajou-user v-show="!show" @AjouteUtilisteur="Ajout"></ajou-user>
    <!--fin ajout users-->

  </div>
</template>

<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from "axios";
import ListeUser from "../components/ListeUser.vue";
import AjouUser from "../components/AjoutUsers.vue";
import DetailUser from "../components/DetailUser.vue";
import EditUser from "../components/EditUser.vue";
import LoadingBare from "../components/LoadingBare.vue";
export default {
  name: "ut",
  components: {
    ListeUser,
    AjouUser,
    DetailUser,
    EditUser,
    LoadingBare,
  },
  data: () => {
    return {
      Administrateurs: [],
      Utilisateurs: [],
      details: "",
      mm: "",
      active_el: "",
      affiche: true,
      x: "",
      show: true,
     role:"",
    };
  },
  async created() {
   //get role
    this.role=(await axios.get("http://localhost:3000/api/Roles/"+localStorage.getItem('role'),{
      headers:{
        Authorization:'Bearer ' + localStorage.getItem('token')
      }
    }))
      .data;
    //select administrateur
    let admin = (await axios.get("http://localhost:3000/api/Utilisateurs",{
      headers:{
        Authorization:'Bearer ' + localStorage.getItem('token')
      }
    }))
      .data;
    this.Administrateurs = admin.filter((s) => s.idRole == 2);
   this.details = admin.filter(s=>s.idProprietaire== localStorage.getItem('id'))[0];
    this.active_el = localStorage.getItem('id');   
    this.Utilisateurs = admin.filter((s) => s.idRole == 3);
  },
  mounted() {
    this.ShowLoade();
  },
  methods: {
    deconnection(){
      this.$router.push({ name: "Login" });
    },
    Ajout(utilisateur) {
      if (utilisateur.idRole == 2) {
        this.Administrateurs.push(utilisateur);
        //this.show=f;
      } else {
        this.Utilisateurs.push(utilisateur);
       // this.show=f;
      }
    },
    ShowLoade() {
      setTimeout(() => {
        this.show = false;
      }, 400);
    },
    edit(e) {
      this.x = e;
      this.affiche = false;
    },
    detail(e) {
      this.mm = e;
    },
    malek() {
      swal
        .fire({
          title: "Deconnecté ?",
          text: "",
          icon: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-warning",
          confirmButtonText: "Yes, Deconnecté !",
        })
        .then((result) => {
          if (result.isConfirmed) {
           this.deconnection();
          }
        });
    },
  },
  watch: {
    mm() {
      this.details = this.mm;
    },
  },
};
</script>
<style >
@import url("https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css");
.navbar {
  background-color: #9a9a9a;
  box-shadow: 0.1px 53px #9a9a9a;
}

.btn:hover {
  color: #fff;
}

.input-text:focus {
  box-shadow: 0px 0px 0px;
  border-color: #f8c146;
  outline: 0px;
}

.form-control {
  border: 1px solid #f8c146;
}
</style>
