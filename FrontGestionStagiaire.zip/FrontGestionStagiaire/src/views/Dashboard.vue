<template>
    <div class="dashboard">
        <Sidebar/>
        <div class="content" style="overflow: scroll; width:99.5%;height:98%">
            <router-view/>
        </div>
    </div>
</template>

<script>
import Sidebar from '../components/Sidebar'
export default {
    name: 'home',

    components: {
        Sidebar
    }
}
</script>

<style>
.dashboard {
    display: grid;
    grid-template-columns: 1fr 5fr;
    background-color: orange;
    height: 100vh;
    width: 100vw;
}

.content {
    background-color: #E3E3E3;
    border-radius: 10px;
    margin: 6px 6px 6px 0px;
}
</style>