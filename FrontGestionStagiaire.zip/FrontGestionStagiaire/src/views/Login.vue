<template>
  <div class="container">
    <div class="login-box">
      <div class="row">
        <div class="col-sm-6">
          <div class="logo" style="font-size: 75px">
            <span class="logo-font">Neo</span>
            Ledege
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6">
          <br />
          <h3 class="header-title">Connectez-Vous</h3>
          <div
            v-if="error"
            class="alert alert-warning "
            role="alert"
            style="width: 50%; margin-left: 147px"
          >
           {{error}}
          </div>
          <form class="login-form">
            <div class="form-group">
              <input
                type="text"
                class="form-control"
                placeholder="UserName"
                v-model="UserName"
              />
            </div>
            <div class="form-group">
              <input
                type="Password"
                class="form-control"
                placeholder="Password"
                v-model="Password"
              />
            </div>
            <div class="form-group">
              <button
                type="button"
                class="btn btn-primary btn-block"
                style="width: 150px; font-family: cursive; font-size: 30px"
                @click="login()"
              >
                login
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: "Login",
  data: () => {
    return {
      UserName: "",
      Password: "",
      Token: null,
      utilisteur: "",
      error:"",
    };
  },

  methods: {
    login() {
      
      const user = {
        nom: this.UserName,
        prenom: "mm",
        email: "hh",
        motdepasse: this.Password,
        idRole: "2",
      };
      
      axios
        .post("http://localhost:3000/api/Utilisateurs/login", user)
        .then(( res ) => {
         
            this.Token = res.data.token;
            this.utilisteur = res.data.validUser;
            if (this.Token != null) {
              this.$router.push({ name: "dashbord" });
            }
            localStorage.setItem("token", this.Token);
            localStorage.setItem("id", this.utilisteur.idProprietaire);
            localStorage.setItem("role", this.utilisteur.idRole);
           
          
        }).
        catch(()=>{
            this.error ="Invalid username/pasword";
        });
    },
  },
};
</script>
<style>
.login-box {
  background-image: url("../assets/lo.jpg");
  background-size: cover;
  background-position: center;
  padding: 50px;
  margin: 25px auto;
  min-height: 700px;
  -webkit-box-shadow: 0 2px 60px -5px rgba(0, 0, 0, 0.1);
  box-shadow: 0 2px 60px -5px rgba(0, 0, 0, 0.1);
  border-radius: 20px;
}

.header-title {
  font-family: cursive;
  font-size: 30px;
  text-align: center;
  margin-bottom: 70px;
  color: #888888;
}

.login-form {
  max-width: 300px;
  margin: 0 auto;
}

.login-form .form-control {
  font-family: cursive;
  border-radius: 50px;
  margin-bottom: 40px;
  text-align: center;
  border-color: orange;
}

.login-form .form-group {
  position: relative;
}

.login-form .form-group .forgot-password {
  position: absolute;
  top: 15px;
  right: 15px;
}

.login-form .btn {
  border-radius: 100px;
  margin-bottom: 50px;
}

.login-form .btn.btn-primary {
  background: orange;
  border-color: orange;
}
</style>
