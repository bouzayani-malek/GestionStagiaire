<template>
  <div class="container">
    <p></p>

    <div class="row">
      <div class="col">
        <!--menu users-->

        <nav
          class="navbar navbar-light"
          style="background-color: #9a9a9a; box-shadow: 0.1px 53px #9a9a9a"
        >
          <div class="container-fluid">
            <a class="navbar-brand log" >{{role.role1}}</a>
            <button type="button" class="btn btn-warning rounded-circle"   @click="malek()">
              <i class="bi bi-power"></i>
            </button>
          </div>
        </nav>
      </div>
    </div>

    <!--fin menu users-->

    <p></p>
   <loading-bare v-show="show"></loading-bare>
    <div class="container">
      <div class="row">
        <!--liste stage-->
        <liste-stagiaire
          @retour="Retour"
          v-show="affiche"
          :Stagiaires="Stagiaires"
          :Etat="Etat"
        ></liste-stagiaire>

        <!--fin liste stage-->

        <!--ajouter stage-->
        <detail-stagiaire
          v-show="!affiche"
          @retour="RetourDetaille"
          :etatstagiaire="etatstagiaire"
          :Stagiaire="Stagiaire"
          :utilisateur="utilisateur"
          :Etat="Etat"
        ></detail-stagiaire>
        <!--fin ajouter-->
      </div>
    </div>
  </div>
</template>

<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from "axios";
import ListeStagiaire from "../components/ListeStagiaire.vue";
import DetailStagiaire from "../components/DetailStagiaire.vue";
import LoadingBare from "../components/LoadingBare.vue";
export default {
  name: "Stagiaire",
  data: () => {
    return {
      affiche: true,
      Stagiaires: "",
      Etat: "",
      Stagiaire: "",
      etatstagiaire: "",
      utilisateur: "",
      show:true,
         role:"",
    };
  },
  components: {
    ListeStagiaire,
    DetailStagiaire,
    LoadingBare
  },
   mounted() {
    this.ShowLoade();
  },
  methods: {
      deconnection(){
      this.$router.push({ name: "Login" });
    },
       malek() {
      swal
        .fire({
          title: "Deconnecté ?",
          text: "",
          icon: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-warning",
          confirmButtonText: "Yes, Deconnecté !",
        })
        .then((result) => {
          if (result.isConfirmed) {
           this.deconnection();
          }
        });
    },
     ShowLoade() {
      setTimeout(() => {
        this.show = false;
      }, 400);
    },
    Retour(e, stagiaire, etat) {
      this.affiche = e;
      this.Stagiaire = stagiaire;
      this.etatstagiaire = etat;
    },
    RetourDetaille(e,etat){
      this.affiche=e;
      this.etatstagiaire=etat;
    }
  },
  async created() {
    //get role
    this.role=(await axios.get("http://localhost:3000/api/Roles/"+localStorage.getItem('role'),{
      headers:{
        Authorization:'Bearer ' + localStorage.getItem('token')
      }
    }))
      .data;
    this.Stagiaires = (
      await axios.get("http://localhost:3000/api/Stagiaires",{
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
    ).data;
    this.Etat = (
      await axios.get("http://localhost:3000/api/EtatStagiaires",{
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
    ).data;
    this.utilisateur = (
      await axios.get("http://localhost:3000/api/Utilisateurs",{
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
    ).data;
  },
};
</script>
<style >
@import url("https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css");
.navbar {
  background-color: #9a9a9a;
  box-shadow: 0.1px 53px #9a9a9a;
}

.btn:hover {
  color: #fff;
}

.input-text:focus {
  box-shadow: 0px 0px 0px;
  border-color: #f8c146;
  outline: 0px;
}

.form-control {
  border: 1px solid #f8c146;
}
</style>