import Vue from 'vue'
import App from './App.vue'
import router from './router'

import"bootstrap"
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import CKeditor from "ckeditor4-vue"

Vue.config.productionTip = false

Vue.use(CKeditor)
new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
