<template>
  <div class="page-container page-content">
    <div class="col logo">
      <div class="card">
        <div class="card-body">
          <!--debut button recherche-->

          <div class="d-grid gap-2 d-md-flex">
            <div class="col-sm-4 log"></div>
            <div class="col-sm-4 log">
              <div class="input-group mt-2">
                <input
                  type="text"
                  class="form-control"
                  placeholder="Rechercher"
                  aria-label="Recipient's username"
                  aria-describedby="button-addon2"
                  v-model="Shearch"
                />

                <button
                  class="btn btn-warning"
                  type="button"
                  id="button-addon2"
                  disabled
                >
                  <i class="bi bi-search"></i>
                </button>
              </div>
            </div>
            <div class="col-sm-2 log"></div>
          </div>
          <!--fin button recherche-->
          <!--form 1-->
          <div class="col-sm mt-4" v-if="listeRecherche">
            <!-- liste recherche-->
            <div class="card">
              <div class="card-body" v-if="datapage.length">
                <!--admin-->
                <div
                  v-for="Stagiaire in datapage.slice().reverse()"
                  :key="Stagiaire.idStagiaire"
                >
                  <div class="row ma">
                    <div class="col-sm-2">
                      <div
                        class="rounded-circle"
                        style="
                          background-color: white;
                          width: 75px;
                          heigth: 75px;
                          margin-top: 16.5px;
                          font-family: Arial, Helvetica, sans-serif;
                          color: blue;
                        "
                      >
                        <h1 style="text-transform: uppercase">
                          {{ Stagiaire.prenom[0] }}{{ Stagiaire.nom[0] }}
                        </h1>
                      </div>
                    </div>
                    <div class="col-sm-3 log" style="margin-top: 22px">
                      <h3>{{ Stagiaire.prenom }} {{ Stagiaire.nom }}</h3>
                    </div>
                    <div class="col-sm-2 log" style="margin-top: 27px">
                      <h5>{{ Stagiaire.commentaire.length }}+ Commentaires</h5>
                    </div>
                    <div class="col-sm-5 log">
                      <div class="row">
                        <!--list-->
                        <div class="col-sm log" style="margin-top: 20px">
                          <a
                            class="btn btn-secondary"
                            role="button"
                            style="
                              border-radius: 25px;
                              border: 3px solid orange;
                            "
                          >
                            {{ GetEtat(Stagiaire.idEtatStagiare) }}
                          </a>
                        </div>
                        <!--fin list-->
                        <!--voir-->

                        <div class="col-sm-3 log" style="margin-top: 20px">
                          <button
                            class="btn btn-warning rounded-circle"
                            type="button"
                            @click="
                              Affiche(
                                false,
                                Stagiaire,
                                GetEtat(Stagiaire.idEtatStagiare)
                              )
                            "
                          >
                            <i class="bi bi-eye"></i>
                          </button>
                        </div>
                        <!--fin voir-->
                      </div>
                    </div>
                  </div>
                  <p></p>
                </div>

                <!-- fin admin-->
              </div>
              <div v-else>
                <div class="row ma">
                  <div class="col-sm-12" style="margin-top: 20px">
                    <h1>Not Found</h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--fin liste recherche-->
          <!-- liste non recherche-->
          <div v-else class="col-sm mt-4">
            <div class="card">
              <div class="card-body">
                <!--admin-->
                <div
                  v-for="Stagiaire in datapage.slice().reverse()"
                  :key="Stagiaire.idStagiaire"
                >
                  <div class="row ma">
                    <div class="col-sm-2">
                      <div
                        class="rounded-circle"
                        style="
                          background-color: white;
                          width: 75px;
                          heigth: 75px;
                          margin-top: 16.5px;
                          font-family: Arial, Helvetica, sans-serif;
                          color: blue;
                        "
                      >
                        <h1 style="text-transform: uppercase">
                          {{ Stagiaire.prenom[0] }}{{ Stagiaire.nom[0] }}
                        </h1>
                      </div>
                    </div>
                    <div class="col-sm-3 log" style="margin-top: 22px">
                      <h3>{{ Stagiaire.prenom }} {{ Stagiaire.nom }}</h3>
                    </div>
                    <div class="col-sm-2 log" style="margin-top: 27px">
                      <h5>{{ Stagiaire.commentaire.length }}+ Commentaires</h5>
                    </div>
                    <div class="col-sm-5 log">
                      <div class="row">
                        <!--list-->
                        <div class="col-sm log" style="margin-top: 20px">
                          <a
                            class="btn btn-secondary"
                            role="button"
                            style="
                              border-radius: 25px;
                              border: 3px solid orange;
                            "
                          >
                            {{ GetEtat(Stagiaire.idEtatStagiare) }}
                          </a>
                        </div>
                        <!--fin list-->
                        <!--voir-->

                        <div class="col-sm-3 log" style="margin-top: 20px">
                          <button
                            class="btn btn-warning rounded-circle"
                            type="button"
                            @click="
                              Affiche(
                                false,
                                Stagiaire,
                                GetEtat(Stagiaire.idEtatStagiare)
                              )
                            "
                          >
                            <i class="bi bi-eye"></i>
                          </button>
                        </div>
                        <!--fin voir-->
                      </div>
                    </div>
                  </div>
                  <p></p>
                </div>

                <!-- fin admin-->
              </div>
            </div>
          </div>
          <!--fin liste non recherche-->
          <!--fin from-->
          <p></p>
              <!--pagination-->
          <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
              <li @click="getPreviewPage()" class="page-item">
                <a class="page-link">Previous</a>
              </li>
              <li v-for="page in totalPagination()" :key="page" @click="getDatapage(page)" class="page-item" ><a class="page-link" >{{page}}</a></li>
              <li @click="getNextPage()" class="page-item"><a class="page-link" >Next</a></li>
            </ul>
          </nav>
           <!--fin pagination-->
        </div>
      </div>
  
      <br />
    </div>
    
  </div>
</template>
<script>
export default {
  name: "ListeStagiaire",
  props: ["Stagiaires", "Etat"],
  data: () => {
    return {
      listeRecherche: "",
      Shearch: "",
      filterStyle: {
        background: "#ffa600",
      },
          nombreelement:4,
          datapage:[],
          pageActuel:1,

    };
  },
  mounted(){
  this.InitData()
  },
  watch: {
    Shearch() {
      if(this.Shearch==""){
         this.datapage=this.Stagiaires.slice(0,4);
         this.listeRecherche="";
      }else{
        this.listeRecherche=1;
      this.datapage = this.Stagiaires.filter((s) =>
        s.nom.startsWith(this.Shearch)
      );}
    },
  },
  methods: {
   //pagination 
     InitData() {
      setTimeout(() => {
     this.datapage=this.Stagiaires.slice(0,4)
      }, 100);
    },
   totalPagination(){
   return Math.ceil(this.Stagiaires.length / this.nombreelement);
   },
   getDatapage(i){
     this.pageActuel=i
     this.datapage=[];
     let ini =((i)*this.nombreelement)-this.nombreelement;
     let fin =((i)*this.nombreelement);
     this.datapage=this.Stagiaires.slice(ini,fin); 
   },
   getPreviewPage(){
     if(this.pageActuel>1){
       this.pageActuel--;
     }
     this.getDatapage(this.pageActuel);
   },
    getNextPage(){
     if(this.pageActuel<this.totalPagination()){
       this.pageActuel++;
     }
     this.getDatapage(this.pageActuel);
   },
   //fin pagination





    Affiche(r, stagiare, etat) {
      this.$emit("retour", r, stagiare, etat);
    },
    GetEtat(id) {
      return this.Etat.filter((s) => s.idEtatStagiare == id).map(
        (s) => s.etatStagiaire1
      )[0];
    },
  },
};
</script>
<style>
.ma {
  position: relative;
  display: flex;
  height: 80px;
  min-width: 0;
  word-wrap: break-word;
  background-color: rgb(207, 207, 207);
  background-clip: border-box;
  border-radius: 20px;
}
.breadcrumb > li + li:before {
  content: "" !important;
}

.breadcrumb {
  padding: 25px;
  font-size: 14px;
  color: #aaa !important;
  letter-spacing: 2px;
  border-radius: 5px !important;
}

.first-1 {
  background-color: white !important;
}

a {
  text-decoration: none !important;
}

a:focus,
a:active {
  outline: none !important;
  box-shadow: none !important;
}

.first span {
  color: black;
}
</style>  