<template>
  <div class="page-container page-content">
    <div class="col logo">
      <div class="card">
        <div class="card-body">
          <!--boutton-->
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button
              class="btn btn-warning"
              style="border-radius: 20px"
              type="button"
              @click="Retour()"
            >
              <i class="bi bi-arrow-left-circle"></i> Retour
            </button>
          </div>

          <!--fin boutton-->
          <!--debut button-->

          <!--fin-->
          <!--form 1-->
          <div class="col-sm mt-4">
            <div class="card m">
              <div class="card-body">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="card">
                      <div class="row">
                        <div class="col-sm-12">
                          {{ this.utilisateurAfecter.length }} Utilisateurs
                          affectés a ce stage :
                        </div>
                      </div>
                      <hr />

                      <div
                        class="row"
                        style="margin-left: 20px"
                        v-for="affecte in utilisateurAfecter"
                        :key="affecte.idStage"
                      >
                        <div class="col-sm-3">
                          <img
                            src="../assets/admin.png"
                            class="rounded-circle float-start"
                            alt="..."
                            width="50px"
                          />
                        </div>
                        <div class="col-sm-5">
                          <p style="font-size: 25px">
                            {{ GetUtilisateurNom(affecte.idProprietaire) }}
                            {{ GetUtilisateurPrenom(affecte.idProprietaire) }}
                          </p>
                        </div>
                        <div class="col-sm-4">
                          <a
                            class="btn btn-outline-danger rounded-circle"
                            @click="retireraffecter(affecte)"
                          >
                            <i class="bi bi-person-dash"></i>
                          </a>
                        </div>
                        <hr />
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="card">
                      <div class="row">
                        <div class="col-sm-7">
                          {{ Listeutilisateur.length }} utilisateurs:
                        </div>
                      </div>
                      <hr />

                      <div
                        class="row"
                        style="margin-left: 20px; margin-top: 10px"
                        v-for="utilisateur in Listeutilisateur"
                        :key="utilisateur.idProprietaire"
                      >
                        <div class="col-sm-3">
                          <img
                            src="../assets/admin.png"
                            class="rounded-circle float-start"
                            alt="..."
                            width="50px"
                          />
                        </div>
                        <div class="col-sm-5">
                          <p style="font-size: 25px">
                            {{ utilisateur.nom }} {{ utilisateur.prenom }}
                          </p>
                        </div>
                        <div class="col-sm-4">
                          <a
                            class="btn btn-outline-warning rounded-circle"
                            @click="affecter(utilisateur.idProprietaire)"
                          >
                            <i class="bi bi-person-plus"></i>
                          </a>
                        </div>
                    
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        
          <br />
        </div>
      </div>
      <br />
    </div>
  </div>
</template>
<script>
import axios from"axios";
import swal from "sweetalert2";
window.Swal = swal;
export default {
  name: "AffecterStage",
  props: ["idstage", "utilisateurAfecter", "Listeutilisateur"],
  data: () => {
    return {
      filterStyle: {
        background: "#ffa600",
      },
    };
  },
  methods: {
    Retour() {
      this.$emit("retour", false);
    },
    GetUtilisateurNom(idProprietaire) {
      return this.Listeutilisateur.filter(
        (u) => u.idProprietaire == idProprietaire
      )[0].nom;
    },
    GetUtilisateurPrenom(idProprietaire) {
      return this.Listeutilisateur.filter(
        (u) => u.idProprietaire == idProprietaire
      )[0].prenom;
    },
    affecter(id) {
       const today = new Date();
       const date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
       const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
       const dateTime = date +' '+ time;
      let n = 0;
      const affecte = {
        date: dateTime,
        idStage: this.idstage,
        idProprietaire: id,
      };
      this.utilisateurAfecter.forEach((element) => {
        if (element.idProprietaire == affecte.idProprietaire) {
          n = 1;
        }
      });
      if (n != 1) {
           axios.post("http://localhost:3000/api/Satgeutilisateurs", affecte,{
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
      .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
        this.utilisateurAfecter.push(affecte);
      } else {
        swal.fire("Exsiste!", "", "warning");
      }
    },
    retireraffecter(affecte) {
      this.utilisateurAfecter.splice(
        this.utilisateurAfecter.indexOf(affecte),
        1
      );
      this.Deleteuser(affecte.idProprietaire);
    },
     Deleteuser: function (id) {
      axios
        .delete("http://localhost:3000/api/Satgeutilisateurs/" + id, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
    },
      
  },
};
</script>
<style>
.m {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  word-wrap: break-word;
  background-color: rgb(207, 207, 207);
  background-clip: border-box;
  border: 1px solid rgba(0, 0, 0, 0.125);
}
.breadcrumb > li + li:before {
  content: "" !important;
}

.breadcrumb {
  padding: 25px;
  font-size: 14px;
  color: #aaa !important;
  letter-spacing: 2px;
  border-radius: 5px !important;
}

.first-1 {
  background-color: white !important;
}

a {
  text-decoration: none !important;
}

a:focus,
a:active {
  outline: none !important;
  box-shadow: none !important;
}

.first span {
  color: black;
}

.active-1,
.active-2 {
  font-size: 20px !important;
  padding-bottom: 12px !important;
  padding-top: 12px !important;
  padding-right: 40px !important;
  padding-left: 40px !important;
  border-radius: 200px !important;
  background-color: rgb(207, 207, 207);
  margin: 10px;
}
</style>  