<template>
  <div class="page-container page-content">
    <div class="col logo">
      <div class="card">
        <div class="card-body">
          <!--boutton-->
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button
              class="btn btn-warning"
              style="border-radius: 20px"
              type="button"
              @click="Retour()"
            >
              <i class="bi bi-arrow-left-circle"></i> Retour
            </button>
          </div>

          <!--fin boutton-->
          <!--debut button-->

          <div class="d-flex justify-content-center">
            <nav aria-label="breadcrumb " class="first d-md-flex">
              <ol class="breadcrumb indigo lighten-6 first-1">
                <li class="breadcrumb-item">
                  <a
                    class="black-text active-2"
                    :style="show ? filterStyle : null"
                    ><span>Stage</span></a
                  >
                </li>

              </ol>
            </nav>
          </div>
          <!--fin-->
          <!--form 1-->
          <div class="col-sm" v-show="show">
            <div class="m card">
              <div class="card-body">
                <form class="was-validated">
                  <div class="mb-3">
                    <label for="titre" class="form-label">Titre :</label>
                    <input
                      type="text"
                      class="form-control is-valid"
                      id="titre"
                      placeholder="Titre d'un stage"
                      v-model="titre"
                      required
                    />
                  </div>
                  <div class="mb-3">
                    <label for="nombre" class="form-label"
                      >Nombre stagiaire :</label
                    >
                    <input
                      type="text"
                      class="form-control is-valid"
                      id="nombre"
                      placeholder="Nombre stagiaire"
                      v-model="nombreStagiaire"
                      required
                    />
                  </div>
                  <div class="mb-3">
                    <label for="image" class="form-label">Image :</label>
                    <input
                      type="file"
                      class="form-control is-valid"
                      id="image"
                      @change="FileSelected"
                      required
                    />
                  </div>
        
                  <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label"
                      >Description :
                    </label>
                    <ckeditor
                     
                      id="exampleFormControlTextarea1" 
                      v-model="description"
                    ></ckeditor>
                  </div>

                  <!--boutton-->
                  <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button
                      class="btn btn-warning"
                      type="button"
                      style="border-radius: 20px"
                      @click="Notification()"
                    >
                      <i class="bi bi-person-plus"></i> Ajouter
                    </button>
                  </div>

                  <!--fin boutton-->
                </form>
              </div>
            </div>
          </div>
          
          <br />
        </div>
      </div>
      <br />
    </div>
  </div>
</template>
<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from "axios";
export default {
  name: "AjoutStage",
  data: () => {
    return {
      titre: "",
      nombreStagiaire: "",
      description: "",
      image: "",
      show: true,
      filterStyle: {
        background: "#ffa600",
      },
     
    };
  },
  methods: {
    FileSelected(event){
          this.image=event.target.files[0].name;
    },
   
    AjoutStage() {
      const Stage = {
        titre: this.titre,
        description: this.description,
        nombreStagiaire: this.nombreStagiaire,
        image: this.image,
        etat: 1,
        idProprietaire: localStorage.getItem("id"),
      };
      axios
        .post("http://localhost:3000/api/Stages", Stage, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
    },
    Notification() {
      this.AjoutStage();

      swal
        .fire("Ajouter!", "Your donation has been Ajouter.", "success")
        .then((result) => {
          if (result.isConfirmed) {
            this.Retour();
          }
        });
    },

    Retour() {
      this.$emit("retour", false);
    },
  },
};
</script>
<style>
.m {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  word-wrap: break-word;
  background-color: rgb(207, 207, 207);
  background-clip: border-box;
  border: 1px solid rgba(0, 0, 0, 0.125);
}
.breadcrumb > li + li:before {
  content: "" !important;
}

.breadcrumb {
  padding: 25px;
  font-size: 14px;
  color: #aaa !important;
  letter-spacing: 2px;
  border-radius: 5px !important;
}

.first-1 {
  background-color: white !important;
}

a {
  text-decoration: none !important;
}

a:focus,
a:active {
  outline: none !important;
  box-shadow: none !important;
}

.first span {
  color: black;
}

.active-1,
.active-2 {
  font-size: 20px !important;
  padding-bottom: 12px !important;
  padding-top: 12px !important;
  padding-right: 40px !important;
  padding-left: 40px !important;
  border-radius: 200px !important;
  background-color: rgb(207, 207, 207);
  margin: 10px;
}
</style>  