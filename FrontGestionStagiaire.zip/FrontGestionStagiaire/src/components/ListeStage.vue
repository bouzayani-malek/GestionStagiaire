<template>
  <div class="page-container page-content">
    <div class="col logo">
      <div class="card">
        <div class="card-body">
          <!--boutton-->
          <div class="d-grid gap-2 d-md-flex">
            <div class="col-sm-4 log"></div>
            <div class="col-sm-4 log">
              <div class="input-group mt-2">
                <input
                  type="text"
                  class="form-control"
                  placeholder="Rechercher"
                  aria-label="Recipient's username"
                  aria-describedby="button-addon2"
                  v-model="Shearch"
                />

                <button
                  class="btn btn-warning"
                  type="button"
                  id="button-addon2"
                  disabled
                >
                  <i class="bi bi-search"></i>
                </button>
              </div>
            </div>
            <div class="col-sm-2 log"></div>
            <div class="col-sm log">
              <button
                class="btn btn-warning"
                type="button"
                style="border-radius: 20px"
                @click="CreeStage()"
              >
                <i class="bi bi-person-plus"></i> Crée Stage
              </button>
            </div>
          </div>
          <!--fin boutton-->

          <!--form 1-->
          <div class="col-sm mt-4" v-if="listeRecherche">
            <div class="card">
              <div class="card-body" v-if="datapage.length">
                <!--admin-->
                <div v-for="stage in datapage" :key="stage.idStage">
                  <div class="row l ma">
                    <div class="col-sm-2">
                      <img
                        src="../assets/admin.png"
                        class="rounded-circle float-start"
                        alt="..."
                        width="50px"
                        style="margin-top: 13px"
                      />
                    </div>
                    <div class="col-sm-2 log" style="margin-top: 22px">
                      <h3>{{ stage.titre }}</h3>
                    </div>
                    <div class="col-sm-2 log" style="margin-top: 27px">
                      <h5>
                        {{ stage.stagiaire.length }}+ demandes
                        <button
                          v-if="stage.stagiaire.length != 0"
                          class="btn rounded-circle"
                          type="button"
                          @click="
                            voireStagiaire(stage.stagiaire, stage.idStage)
                          "
                          style="color: black"
                        >
                          <i class="bi bi-eye"></i>
                        </button>
                      </h5>
                    </div>
                    <div class="col-sm-2 log">
                      <div class="row">
                        <!--edit-->
                        <div class="col-sm log" style="margin-top: 20px">
                          <button
                            class="btn btn-warning rounded-circle"
                            type="button"
                            @click="EditStage(stage)"
                          >
                            <i class="bi bi-pencil-square"></i>
                          </button>
                        </div>
                        <!--fin edit-->
                        <!--voir-->

                        <div
                          class="col-sm log"
                          style="margin-top: 20px"
                          v-if="stage.etat == 1"
                        >
                          <button
                            class="btn btn-warning rounded-circle"
                            type="button"
                            @click="demande(stage.idStage)"
                          >
                            <i class="bi bi-eye"></i>
                          </button>
                        </div>
                        <!--fin voir-->
                      </div>
                    </div>

                    <div class="col-sm-2 log" style="margin-top: 20px">
                      <a
                        class="btn btn-secondary"
                        role="button"
                        style="border-radius: 25px; border: 3px solid orange"
                        @click="AffecterStage(stage.idStage)"
                      >
                        Affecter
                      </a>
                    </div>

                    <div class="col-sm-2" style="margin-top: 20px">
                      <div class="switch-toggle" v-show="stage.etat == 1">
                        <input
                          type="checkbox"
                          :id="stage.idStage"
                          checked
                          disabled
                        />
                        <label
                          :for="stage.idStage"
                          @click="change(stage.idStage, stage.etat, stage)"
                        ></label>
                      </div>

                      <div class="switch-toggle" v-show="stage.etat == 2">
                        <input type="checkbox" :id="stage.idStage" disabled />
                        <label
                          :for="stage.idStage"
                          @click="change(stage.idStage, stage.etat, stage)"
                        ></label>
                      </div>
                    </div>
                  </div>

                  <div v-if="stage.idStage == idstage">
                    <div
                      class="alert alert-primary"
                      role="alert"
                      v-for="stagiaire in listeStagiaire"
                      :key="stagiaire.idStagiaire"
                    >
                      {{ stagiaire.nom }}
                    </div>
                  </div>
                  <div v-else><p></p></div>
                </div>
              </div>

              <div v-else>
                <div class="row ma">
                  <div class="col-sm-12" style="margin-top: 20px">
                    <h1>Not Found</h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm mt-4" v-else v-show="show">
            <div class="card">
              <div class="card-body">
                <!--admin-->

                <div v-for="stage in datapage.slice()" :key="stage.idStage">
                  <div class="row l ma">
                    <div class="col-sm-2">
                      <img
                        src="../assets/admin.png"
                        class="rounded-circle float-start"
                        alt="..."
                        width="50px"
                        style="margin-top: 13px"
                      />
                    </div>
                    <div class="col-sm-2 log" style="margin-top: 22px">
                      <h3>{{ stage.titre }}</h3>
                    </div>
                    <div class="col-sm-2 log" style="margin-top: 27px">
                      <h5>
                        {{ stage.stagiaire.length }}+ demandes
                        <button
                          v-if="stage.stagiaire.length != 0"
                          class="btn rounded-circle"
                          type="button"
                          @click="
                            voireStagiaire(stage.stagiaire, stage.idStage)
                          "
                          style="color: black"
                        >
                          <i class="bi bi-eye"></i>
                        </button>
                      </h5>
                    </div>
                    <div class="col-sm-2 log">
                      <div class="row">
                        <!--edit-->
                        <div class="col-sm log" style="margin-top: 20px">
                          <button
                            class="btn btn-warning rounded-circle"
                            type="button"
                            @click="EditStage(stage)"
                          >
                            <i class="bi bi-pencil-square"></i>
                          </button>
                        </div>
                        <!--fin edit-->
                        <!--voir-->

                        <div
                          class="col-sm log"
                          style="margin-top: 20px"
                          v-if="stage.etat == 1"
                        >
                          <button
                            class="btn btn-warning rounded-circle"
                            type="button"
                            @click="demande(stage.idStage)"
                          >
                            <i class="bi bi-eye"></i>
                          </button>
                        </div>
                        <!--fin voir-->
                      </div>
                    </div>

                    <div class="col-sm-2 log" style="margin-top: 20px">
                      <a
                        class="btn btn-secondary"
                        role="button"
                        style="border-radius: 25px; border: 3px solid orange"
                        @click="AffecterStage(stage.idStage)"
                      >
                        Affecter <i class="bi bi-arrow-bar-right"></i>
                      </a>
                    </div>

                    <div class="col-sm-2" style="margin-top: 20px">
                      <div class="switch-toggle" v-show="stage.etat == 1">
                        <input
                          type="checkbox"
                          :id="stage.idStage"
                          checked
                          disabled
                        />
                        <label
                          :for="stage.idStage"
                          @click="change(stage.idStage, stage.etat, stage)"
                        ></label>
                      </div>

                      <div class="switch-toggle" v-show="stage.etat == 2">
                        <input type="checkbox" :id="stage.idStage" disabled />
                        <label
                          :for="stage.idStage"
                          @click="change(stage.idStage, stage.etat, stage)"
                        ></label>
                      </div>
                    </div>
                  </div>
                  <div v-if="stage.idStage == idstage">
                    <div
                      class="alert alert-primary"
                      role="alert"
                      v-for="stagiaire in listeStagiaire"
                      :key="stagiaire.idStagiaire"
                    >
                      {{ stagiaire.nom }} {{ stagiaire.prenom }}
                    </div>
                  </div>
                  <div v-else><p></p></div>
                </div>

                <!-- fin admin-->
              </div>
            </div>
          </div>

          <p></p>
          <!--pagination-->
          <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
              <li @click="getPreviewPage()" class="page-item">
                <a class="page-link">Previous</a>
              </li>
              <li
                v-for="page in totalPagination()"
                :key="page"
                @click="getDatapage(page)"
                class="page-item"
              >
                <a class="page-link">{{ page }}</a>
              </li>
              <li @click="getNextPage()" class="page-item">
                <a class="page-link">Next</a>
              </li>
            </ul>
          </nav>
          <!--fin pagination-->

          <!--fin from-->
        </div>
      </div>
      <br />
    </div>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: "ListeStage",
  props: ["stages"],
  data: () => {
    return {
      idstage: "",
      listeStagiaire: "",
      listeRecherche: "",
      Shearch: "",
      show: true,
      filterStyle: {
        background: "#ffa600",
      },
      nombreelement: 4,
      datapage: [],
      pageActuel: 1,
    };
  },
  watch: {
    Shearch() {
      if (this.Shearch == "") {
        this.datapage = this.stages.slice(0, 4);
        this.listeRecherche = "";
      } else {
        this.listeRecherche = 1;
        this.datapage = this.stages.filter((s) =>
          s.titre.startsWith(this.Shearch)
        );
      }
    },
  },
  mounted() {
    this.InitData();
  },
  methods: {
    //pagination
    InitData() {
      setTimeout(() => {
        this.stages = this.stages.reverse();
        this.datapage = this.stages.slice(0, 4);
      }, 400);
    },
    totalPagination() {
      return Math.ceil(this.stages.length / this.nombreelement);
    },
    getDatapage(i) {
   
      this.pageActuel = i;
      this.datapage = [];
      let ini = i * this.nombreelement - this.nombreelement;
      let fin = i * this.nombreelement;
      this.datapage = this.stages.slice(ini, fin);
    },
    getPreviewPage() {
      if (this.pageActuel > 1) {
        this.pageActuel--;
      }
      this.getDatapage(this.pageActuel);
    },
    getNextPage() {
      if (this.pageActuel < this.totalPagination()) {
        this.pageActuel++;
      }
      this.getDatapage(this.pageActuel);
    },
    //pagination
    voireStagiaire(stagiaire, idstage) {
      this.listeStagiaire = stagiaire;
      this.idstage = idstage;
    },
    demande(id) {
      this.$router.push({ name: "DemandeStagiaire", params: { id } });
    },
    change(id, etat, stage) {
      etat == 1 ? (stage.etat = 2) : (stage.etat = 1);
      this.stages[this.stages.indexOf(stage)].etat = stage.etat;
      axios
        .put("http://localhost:3000/api/Stages/" + id, stage, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
    },

    reloadPage: function () {
      window.location.reload();
    },
    CreeStage() {
      this.$emit("ajout-stage", true);
    },
    EditStage(stage) {
      this.$emit("edit-stage", stage);
    },
    AffecterStage(id) {
      this.$emit("affecter-stage", true, id);
    },
  },
};
</script>
<style>
.ma {
  position: relative;
  display: flex;
  height: 80px;
  min-width: 0;
  word-wrap: break-word;
  background-color: rgb(207, 207, 207);
  background-clip: border-box;
  border-radius: 20px;
}
.breadcrumb > li + li:before {
  content: "" !important;
}

.breadcrumb {
  padding: 25px;
  font-size: 14px;
  color: #aaa !important;
  letter-spacing: 2px;
  border-radius: 5px !important;
}

.first-1 {
  background-color: white !important;
}

a {
  text-decoration: none !important;
}

a:focus,
a:active {
  outline: none !important;
  box-shadow: none !important;
}

.first span {
  color: black;
}

.switch-toggle {
  height: 40px;
}

.switch-toggle input[type="checkbox"] {
  position: absolute;
  opacity: 0;
  z-index: -2;
}

.switch-toggle input[type="checkbox"] + label {
  position: relative;
  display: inline-block;
  width: 100px;
  height: 40px;
  border-radius: 20px;
  margin: 0;
  cursor: pointer;
  box-shadow: inset -8px -8px 15px rgba(255, 255, 255, 0.6),
    inset 10px 10px 10px rgba(0, 0, 0, 0.25);
}

.switch-toggle input[type="checkbox"] + label::before {
  position: absolute;
  content: "OFF";
  font-size: 13px;
  text-align: center;
  line-height: 25px;
  top: 8px;
  left: 8px;
  width: 45px;
  height: 25px;
  border-radius: 20px;
  background-color: #d1dad3;
  box-shadow: -3px -3px 5px rgba(255, 255, 255, 0.5),
    3px 3px 5px rgba(0, 0, 0, 0.25);
  transition: 0.3s ease-in-out;
}

.switch-toggle input[type="checkbox"]:checked + label::before {
  left: 50%;
  content: "ON";
  color: #fff;
  background-color: orange;
  box-shadow: -4px -4px 6px rgba(255, 255, 255, 0.5),
    4px 4px 6px rgba(255, 255, 255, 0.5);
}

.dropdown-toggle {
  width: 160px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 20px;
  border: 3px solid orange;
  font-weight: 600;
}

.dropdown-toggle:focus {
  box-shadow: none !important;
}

.dropdown-toggle::after {
  display: none;
}

.dropdown-menu {
  width: 150px;
  border: 3px solid orange;
  padding: 0rem 0;
}

.dropdown-item:focus,
.dropdown-item:hover {
  color: #ffffff;
  background-color: orange;
  padding: 12px;
}

.dropdown-item {
  display: block;
  width: 100%;
  padding: 12px;
}
</style>  