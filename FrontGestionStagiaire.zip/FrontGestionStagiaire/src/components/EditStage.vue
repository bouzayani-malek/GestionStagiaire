<template>
  <div class="page-container page-content">
    <div class="col logo">
      <div class="card">
        <div class="card-body">
          <!--boutton-->
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button class="btn btn-warning" type="button"  style="border-radius: 20px" @click="Retour()">
              <i class="bi bi-arrow-left-circle"></i> Retour
            </button>
          </div>

          <!--fin boutton-->
          <!--debut form-->
          <div class="card mt-4 m">
            <form class="was-validated">
              <div class="row mt-2">
                <div class="col-sm-4 mt-4">
                  <div
                    class="d-flex flex-column align-items-center text-center"
                  >
                    <img
                      class="rounded-circle mt-5"
                      width="150px"
                      src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"
                    /><span
                      ><h3>{{ editstage.titre }}</h3>
                    </span>
                  </div>
                </div>
                <div class="col-sm-8 border-rightn">
                  <div class="row mt-4">
                    <div class="col-sm-4"></div>
                    <div class="col-md-5">
                      <div
                        class="
                          d-flex
                          justify-content-between
                          align-items-center
                          mb-3
                          text-center
                        "
                      >
                        <h4 class="text-center">Stage Setting</h4>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-5">
                      <label class="labels">Titre</label
                      ><input
                        type="text"
                        class="form-control is-valid"
                       
                        required
                       :value="editstage.titre"
                       @input="editstage.titre=$event.target.value"
                         
                      />
                      <div class="invalid-feedback" style="font-size: 13px">
                        Required !
                      </div>
                    </div>
                    <div class="col-md-5">
                      <label class="labels">Nombre stagiaire</label
                      ><input
                        type="text"
                        class="form-control is-valid"
                        :value="editstage.nombreStagiaire"
                       @input="editstage.nombreStagiaire=$event.target.value"
                        required
                      />
                      <div class="invalid-feedback" style="font-size: 13px">
                        Required !
                      </div>
                    </div>
                  </div>

                  <div class="row mt-2">
                    <div class="col-md-10">
                      <label class="labels">Image</label
                      ><input
                        type="file"
                        class="form-control is-valid"
                            @change="FileSelected"
                       
                        required
                      />
                      <div class="invalid-feedback" style="font-size: 13px">
                        Required !
                      </div>
                    </div>
                  </div>

                  <div class="row mt-2">
                    <div class="col-md-10">
                    
                
                    <label for="exampleFormControlTextarea1" class="form-label"
                      >Description :
                    </label>
                    <ckeditor
                    
                      id="exampleFormControlTextarea1" 
                      v-model="description"
                    ></ckeditor>
                  
                      <div class="invalid-feedback" style="font-size: 13px">
                        Required !
                      </div>
                    </div>
                  </div>
                

                  <div class="mt-2 col-md-10">
                    <button
                      class="btn btn-warning"
                      type="button"
                       style="border-radius: 20px"
                      @click="Notification(editstage);"
                    >
                      Save Stage
                    </button>
                  </div>
                </div>
              </div>
              <div class="mt-4"></div>
            </form>
          </div>
          <!--fin from-->
          <div class="mt-4"></div>
        </div>
      </div>
      <br />
    </div>
  </div>
</template>
<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from"axios";
export default {
  name: "EditStage",
  props: ["editstage"], 
  data:()=>{
        return {
          description:'',
          image:'',
        }
  },
  methods: {
     FileSelected(event){
          this.image=event.target.files[0].name;
    },
    Retour() {
      this.$emit("retour", false);
    },
    EditStage(editstage) {
      editstage.description=this.description;
      editstage.image=this.image;
      axios
        .put("http://localhost:3000/api/Stages/"+ editstage.idStage, editstage,{
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
    },
    reloadPage: function () {
      window.location.reload();
    },
    Notification(e) {
      this.EditStage(e);
      swal.fire(
            "Updated!",
            "Your donation has been updated.",
            "success",
        
      );
    },
  
    
  },
 
};
</script>