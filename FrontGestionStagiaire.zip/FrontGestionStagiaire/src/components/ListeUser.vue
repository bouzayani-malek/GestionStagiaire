<template>
  <div class="col-sm-4">
    <div
      class="card"
      style="
        position: relative;
        overflow-y: auto;
        overflow-x: hidden;
        width: 100%;
        height: 70%;
      "
    >
      <div class="card-body">
        <!--admin-->
        <div class="row">
          <div class="col-sm-10">
            <h5 class="card-title text-left logo">
              {{ ListeAdmin.length }} Administrateurs :
            </h5>
          </div>
          <hr />
        </div>

        <div
          @click="
            get(administrateur.idProprietaire);
            detailutilisateur(administrateur);
          "
          :style="
            active_el == administrateur.idProprietaire ||
            (active == administrateur.idProprietaire && show)
              ? filterStyle
              : null
          "
          class="row l"
          v-for="administrateur in ListeAdmin"
          :key="administrateur.idProprietaire"
        >
          <div class="col-sm-2">
            <img
              src="../assets/admin.png"
              class="rounded-circle float-start"
              alt="..."
              width="50px"
            />
          </div>
          <div class="col-sm-6 log">
            <p style="margin-top: 13px">
              {{ administrateur.prenom }} {{ administrateur.nom }}
            </p>
          </div>
          <div class="col-sm-4" style="margin-top: 8px" v-if="voir==1" >
            <a
              class="btn btn-outline-primary rounded-circle"
              @click="editutilisateur(administrateur)"
            >
              <i class="bi bi-pencil-square"></i>
            </a>

            <a
              class="btn btn-outline-danger rounded-circle"
              @click="
                Notification(administrateur.idProprietaire, administrateur)
              "
            >
              <i class="bi bi-person-x"></i>
            </a>
          </div>
        </div>
      
        <!-- fin admin-->

        <!--users-->
        <br />
        <div class="row">
          <div class="col-sm-8">
            <h5 class="card-title text-left logo">
              {{ ListeUtilisateur.length }} Utilisateurs :
            </h5>
          </div>
          <hr />
        </div>

        <div
          @click="
            get(utilisateur.idProprietaire);
            detailutilisateur(utilisateur);
          "
          :style="
            active_el == utilisateur.idProprietaire ||
            (active == utilisateur.idProprietaire && show)
              ? filterStyle
              : null
          "
          class="row l"
          v-for="utilisateur in ListeUtilisateur"
          :key="utilisateur.idProprietaire"
        >
          <div class="col-sm-2">
            <img
              src="../assets/user.png"
              class="rounded-circle float-start"
              alt="..."
              width="50px"
            />
          </div>
          <div class="col-sm-6 log">
            <p style="margin-top: 13px">
              {{ utilisateur.prenom }} {{ utilisateur.nom }}
            </p>
          </div>
          <div class="col-sm-4" style="margin-top: 8px"  v-if="voir==1" >
            <a
              class="btn btn-outline-primary rounded-circle"
              @click="editutilisateur(utilisateur)"
            >
              <i class="bi bi-pencil-square"></i>
            </a>

            <a
              href="#"
              class="btn btn-outline-danger rounded-circle"
              @click="Notification(utilisateur.idProprietaire, utilisateur)"
            >
              <i class="bi bi-person-x"></i>
            </a>
          </div>
        </div>

        <br />
        <!-- fin users-->
      </div>
    </div>
  </div>
</template>
<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from "axios";
export default {
  name: "ListeUser",
  props: ["ListeUtilisateur", "ListeAdmin", "active"],
  data: () => {
    return {
      Administrateurs: [],
      Utilisateurs: [],
      active_el: 0,
      show: true,
      filterStyle: {
        background: "#ffa600",
      },
      voir:localStorage.getItem('id'),
    };
  },
  methods: {
    get: function (id) {
      this.active_el = id;
      this.show = false;
    },
    nombreadmin() {
      return this.ListeAdmin;
    },
    detailutilisateur(detail) {
      this.$emit("affiche-utilisateur", detail);
    },
    editutilisateur(edit) {
      this.$emit("Affiche-edit", edit);
    },
    Deleteuser: function (id) {
      axios
        .delete("http://localhost:3000/api/Utilisateurs/" + id, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
    },
    Notification(id, utilisateur) {
      swal
        .fire({
          title: "Are you sure?",
          text: "You will not be able to recover this donation !",
          icon: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-warning",
          confirmButtonText: "Yes, delete it!",
        })
        .then((result) => {
          if (result.isConfirmed) {
            this.Deleteuser(id);
            swal
              .fire("Deleted!", "Your donation has been deleted.", "success")
              .then((result) => {
                if (result.isConfirmed) {
                  if (utilisateur.idRole == 2) {
                    this.ListeAdmin.splice(
                      this.ListeAdmin.indexOf(utilisateur),
                      1
                    );
                  } else {
                    this.ListeUtilisateur.splice(
                      this.ListeUtilisateur.indexOf(utilisateur),
                      1
                    );
                  }
                }
              });
          }
        });
    },
  },
};
</script>
<style>
.l:hover {
  background-color: orange;
}
.logo {
  font-family: "Script MT";
  font-size: 30px;
  text-align: center;
  color: #888888;
}
.log {
  font-family: "Script MT";

  text-align: center;
  color: #888888;
}

.card {
  border-radius: 20px !important;
  box-shadow: 2px 2px 5px 0px rgb(100, 108, 170);
  transition: 0.8s;
}
</style>
