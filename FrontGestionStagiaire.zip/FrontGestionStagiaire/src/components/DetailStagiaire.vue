<template>
  <div class="page-container page-content">
    <div class="col logo">
      <div class="card">
        <div class="card-body">
          <!--boutton-->
          <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-2">
            <button
              class="btn btn-warning"
              type="button"
              @click="retour(true, etatstagiaire)"
              style="border-radius: 20px"
            >
              <i class="bi bi-arrow-left-circle"></i> Retour
            </button>
          </div>

          <!--fin boutton-->

          <div class="d-flex justify-content-center mt-2"></div>
          <!--fin-->
          <!--form 1-->
          <div class="col-sm">
            <div class="card">
              <div class="card-body">
                <!--admin-->
                <div>
                  <div
                    class="row l"
                    style="
                      background-color: rgb(207, 207, 207);
                      border-radius: 10px;
                    "
                  >
                    <div class="col-sm-2">
                      <div
                        class="rounded-circle"
                        style="
                          background-color: white;
                          width: 150px;
                          heigth: 75px;
                          margin-top: 8px;
                          font-family: Arial, Helvetica, sans-serif;
                          color: blue;
                          margin-left: 20px;
                        "
                      >
                        <h1 style="font-size: 80px; text-transform: uppercase">
                          {{ Stagiaire.prenom[0] }}{{ Stagiaire.nom[0] }}
                        </h1>
                      </div>
                    </div>
                    <div class="col-sm-4 log">
                      <div class="mt-2">
                        <h3>{{ Stagiaire.prenom }} {{ Stagiaire.nom }}</h3>
                      </div>
                      <div class="mt-2">
                        <h5>{{ Stagiaire.email }}</h5>
                      </div>
                    </div>
                    <!--voir-->

                    <div class="col-sm-2 log" style="margin-top: 20px">
                      <button
                        class="btn btn-warning"
                        type="button"
                        style="border-radius: 25px"
                      >
                        Voir Cv <i class="bi bi-eye"></i>
                      </button>
                    </div>
                    <div class="col-sm-4 log">
                      <div class="row">
                        <!--list-->
                        <div
                          class="col-sm log"
                          style="margin-top: 20px; margin-left: 150px"
                        >
                          <div class="dropdown">
                            <a
                              class="btn btn-secondary dropdown-toggle"
                              role="button"
                              id="dropdownMenuLink"
                              data-bs-toggle="dropdown"
                              aria-expanded="false"
                              style="text-align: center"
                              >{{ etatstagiaire }}
                              <i class="bi bi-caret-down"></i>
                            </a>

                            <ul
                              class="dropdown-menu"
                              aria-labelledby="dropdownMenuLink"
                            >
                              <li
                                v-for="etat in Etat"
                                :key="etat.idEtatStagiare"
                              >
                                <a
                                  class="dropdown-item"
                                  @click="
                                    changeEtat(
                                      etat.idEtatStagiare,
                                      Stagiaire,
                                      etat.etatStagiaire1
                                    )
                                  "
                                  >{{ etat.etatStagiaire1 }}</a
                                >
                              </li>
                            </ul>
                          </div>
                        </div>
                        <!--fin list-->
                      </div>
                    </div>
                  </div>
                </div>
                <!-- fin admin-->

                <!--boutton-->
                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-2">
                  <button
                    class="btn btn-warning"
                    type="button"
                    style="border-radius: 20px"
                    @click="Show()"
                  >
                    <i class="bi bi-arrow-left-circle"></i> Ajouter un
                    commentaire
                  </button>
                </div>

                <!--fin boutton-->

                <!--commentaire-->
                <div
                  class="mt-2"
                  v-for="(commentaire, i) in Stagiaire.commentaire"
                  :key="i"
                >
                  <div class="row ma">
                    <div class="col-sm-2">
                      <div
                        class="rounded-circle"
                        style="
                          background-color: white;
                          width: 75px;
                          heigth: 75px;
                          margin-top: 16.5px;
                          font-family: Arial, Helvetica, sans-serif;
                          color: blue;
                          margin-left: 15px;
                        "
                      >
                        <h1 style="text-transform: uppercase">
                          {{ GetPrenom(commentaire.idProprietaire)
                          }}{{ GetNom(commentaire.idProprietaire) }}
                        </h1>
                      </div>
                    </div>
                    <div class="col-sm-6 log" style="margin-top: 22px">
                      <h3>{{ commentaire.commentaire1 }}</h3>
                    </div>

                    <div class="col-sm-4 log" style="margin-top: 22px">
                      <div class="row">
                        <h5>{{ commentaire.date }}</h5>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- fin commentaire-->

                <!--Ajout commentaire-->
                <div class="mt-2" v-show="show">
                  <div class="row ma">
                    <div class="col-sm-2" style="margin-top: 24px">
                      <div class="row">
                        <h5>Votre commentaire :</h5>
                      </div>
                    </div>
                    <div class="col-sm-8 log" style="margin-top: 22px">
                      <div class="input-group mb-3">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Saisir votre commentaire"
                          aria-label="Recipient's username"
                          aria-describedby="button-addon2"
                          style="border-radius: 20px"
                          v-model="commentaire"
                        />
                        <button
                          class="btn btn-warning"
                          type="button"
                          id="button-addon2"
                          style="border-radius: 20px"
                          @click="AjouterCommentaire(Stagiaire.idStagiaire)"
                        >
                          Ajouter
                        </button>
                        <button
                          class="btn btn-danger"
                          type="button"
                          id="button-addon2"
                          style="border-radius: 20px"
                          @click="annuler()"
                        >
                          Annuler
                        </button>
                      </div>
                    </div>

                    <div class="col-sm-2 log" style="margin-top: 22px">
                      <div class="row"></div>
                    </div>
                  </div>
                </div>

                <!-- fin ajout commentaire-->
              </div>
            </div>
          </div>

          <!--fin from-->
        </div>
      </div>
      <br />
    </div>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: "ListeStagiaire",
  props: ["etatstagiaire", "Stagiaire", "utilisateur", "Etat"],
  data: () => {
    return {
      commentaire: "",
      show: false,
      filterStyle: {
        background: "#ffa600",
      },
    };
  },
  methods: {
    retour(e, etatstagiaire) {
      this.$emit("retour", e, etatstagiaire);
    },
    Show() {
      this.show = true;
    },
    GetNom(id) {
      return this.utilisateur
        .filter((s) => s.idProprietaire == id)
        .map((s) => s.nom)[0][0];
    },
    GetPrenom(id) {
      return this.utilisateur
        .filter((s) => s.idProprietaire == id)
        .map((s) => s.prenom)[0][0];
    },
    changeEtat(id, stagiaire, etat) {
      stagiaire.idEtatStagiare = id;
      axios
        .put(
          "http://localhost:3000/api/Stagiaires/" + stagiaire.idStagiaire,
          stagiaire,{
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        }
        )
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
      this.etatstagiaire = etat;
    },
    AjouterCommentaire(idStagiaire) {
        const today = new Date();
       const date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
       const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
       const dateTime = date +' '+ time;
      const commentaires = {
        commentaire1: this.commentaire,
        date: dateTime,
        idStagiaire: idStagiaire,
        idProprietaire: localStorage.getItem('id'),
      };

      if (this.commentaire.trim() != "") {
        axios
          .post("http://localhost:3000/api/Commentaires", commentaires,{
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
          .then((res) => console.log(res))
          .catch((rer) => console.log(rer));
        this.Stagiaire.commentaire.push(commentaires);
      }
      this.commentaire = "";
      this.show = false;
    },
    annuler(){
       this.show = false;
    }
  },
};
</script>
<style>
.breadcrumb > li + li:before {
  content: "" !important;
}

.breadcrumb {
  padding: 25px;
  font-size: 14px;
  color: #aaa !important;
  letter-spacing: 2px;
  border-radius: 5px !important;
}

.first-1 {
  background-color: white !important;
}

a {
  text-decoration: none !important;
}

a:focus,
a:active {
  outline: none !important;
  box-shadow: none !important;
}

.first span {
  color: black;
}

.dropdown-toggle {
  width: 160px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 20px;
  border: 3px solid orange;
  font-weight: 600;
}

.dropdown-toggle:focus {
  box-shadow: none !important;
}

.dropdown-toggle::after {
  display: none;
}

.dropdown-menu {
  width: 150px;
  border: 3px solid orange;
  padding: 0rem 0;
  transform: translate3d(0px, 50px, 0px) !important;
}

.dropdown-item:focus,
.dropdown-item:hover {
  color: #ffffff;
  background-color: orange;
  padding: 12px;
}

.dropdown-item {
  display: block;
  width: 100%;
  padding: 12px;
}
</style>  