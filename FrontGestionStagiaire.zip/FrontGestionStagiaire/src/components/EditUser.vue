<template>
  <div class="col-sm-8 logo">
    <div class="card">
      <div class="card-body">
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
          <button
            class="btn btn-warning"
            type="button"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
            data-bs-whatever="@getbootstrap"
          >
            <i class="bi bi-person-plus"></i>
            Crée niveau
          </button>
        </div>
        <br />

        <div class="card">
          <form class="was-validated">
            <div class="row">
              <div class="col-sm-4">
                <div class="d-flex flex-column align-items-center text-center">
                  <img
                    class="rounded-circle mt-4"
                    width="150px"
                    src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"
                  />
                  <span>
                    <h3>{{ edit.nom }}</h3>
                  </span>
                  <span class="text-black-50">
                    <h6 class="text-right">{{ edit.email }}</h6>
                  </span>
                  <span></span>
                </div>
              </div>
              <div class="col-sm-8 border-rightn mt-4">
                <div class="row">
                  <div class="col-md-3"></div>
                  <div class="col-md-5">
                    <div
                      class="d-flex justify-content-between align-items-center mb-3"
                    >
                      <h4 class="text-right">Profile Settings</h4>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-5">
                    <label class="labels">Prénom</label>
                    <input
                      type="text"
                      class="form-control is-valid"
                      required
                      :value="edit.prenom"
                      @input="edit.prenom = $event.target.value"
                    />
                    <div class="invalid-feedback" style="font-size: 13px;">
                      Required !
                    </div>
                  </div>
                  <div class="col-md-5">
                    <label class="labels">Nom</label>
                    <input
                      type="text"
                      class="form-control is-valid"
                      :value="edit.nom"
                      @input="edit.nom = $event.target.value"
                      required
                    />
                    <div class="invalid-feedback" style="font-size: 13px;">
                      Required !
                    </div>
                  </div>
                </div>

                <div class="row mt-2">
                  <div class="col-md-10">
                    <label class="labels">Email</label>
                    <input
                      type="text"
                      class="form-control is-valid"
                      :value="edit.email"
                      @input="edit.email = $event.target.value"
                      required
                    />
                    <div class="invalid-feedback" style="font-size: 13px;">
                      Required !
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-10">
                    <label class="labels">Mot de passe</label>
                    <input
                      type="text"
                      class="form-control is-valid"
                      :value="edit.motdepasse"
                      @input="edit.motdepasse = $event.target.value"
                      required
                    />
                    <div class="invalid-feedback" style="font-size: 13px;">
                      Required !
                    </div>
                  </div>
                </div>

                <div class="row mt-2">
                  <div class="col-md-10">
                    <label class="labels">Role</label>

                    <select
                      class="form-select is-valid"
                      aria-label="Default select example"
                      id="user-role"
                      v-model="selec"
                      required
                    >
                   
                      <option :value="2">Adminstrateur</option>
                      <option :value="3">Utilisateur</option>
                    </select>
                     
                    
                    <div class="invalid-feedback" style="font-size: 13px;">
                      Required !
                    </div>
                  </div>
                </div>

                <div class="mt-2">
                  <button
                    class="btn btn-warning"
                    type="button"
                    @click="Notification(edit)"
                  >
                    Save Profile
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <br />
  </div>
</template>
<script>
import swal from 'sweetalert2'
window.Swal = swal
import axios from 'axios'
export default {
  name: 'EditUser',
  props: ['edit'],
   data: () => {
    return {
      selec: "",
    };
  },

  methods: {
    EditUser(edit) {
      edit.idRole=this.selec;
      axios
        .put(
          'http://localhost:3000/api/Utilisateurs/' + edit.idProprietaire,
          edit,
          {
            headers: {
              Authorization: 'Bearer ' + localStorage.getItem('token'),
            },
          },
        )
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer))
    },

    Notification(e) {
      this.EditUser(e)
      swal.fire('Updated!', 'Your donation has been updated.', 'success')
    },
  },
}
</script>
<style>
.labels {
  font-size: 11px;
}
.invalid-feedback {
  z-index: 5;

  max-width: 100%;
  padding: 0.25rem 0.5rem;

  color: #fff;
  background-color: orange;
  border-radius: 0.25rem;
}
.l {
  font-size: 13px;
}
.m {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  word-wrap: break-word;
  background-color: rgb(207, 207, 207);
  background-clip: border-box;
  border: 1px solid rgba(0, 0, 0, 0.125);
}
</style>
