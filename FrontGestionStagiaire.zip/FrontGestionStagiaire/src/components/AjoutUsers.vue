<template>
  <div
    class="modal fade"
    id="exampleModal"
    tabindex="-1"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true"
    style="color: orange"
  >
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <div class="logo">
            <span class="logo-font">Neo</span>
            Ledege
          </div>

          <button
            type="button"
            class="btn-close btn-danger"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>
        <div class="modal-body">
          <form class="was-validated">
            <div class="mb">
              <label for="user-name" class="col-form-label logoo">Nom :</label>
              <input
                type="text"
                class="form-control is-valid"
                id="user-name"
                v-model="name"
                required
              />
              <!--alert-->
              <div class="invalid-feedback" style="font-size: 13px">
                Required !
              </div>
              <!--fin alert-->
            </div>

            <div class="mb">
              <label for="user-prenom" class="col-form-label logoo"
                >Prénom :</label
              >
              <input
                type="text"
                class="form-control is-valid"
                id="user-prenom"
                v-model="prenom"
                required
              />
              <!--alert-->
              <div class="invalid-feedback" style="font-size: 13px">
                Required !
              </div>
              <!--fin alert-->
            </div>

            <div class="mb">
              <label for="user-email" class="col-form-label logoo"
                >Email :</label
              >
              <input
                type="email"
                class="form-control is-valid"
                id="user-email"
                v-model="Email"
                required
              />
              <!--alert-->
              <div class="invalid-feedback" style="font-size: 13px">
                Required !
              </div>
              <!--fin alert-->
            </div>

            <div class="mb">
              <label for="user-passe" class="col-form-label logoo"
                >Mot de passe :</label
              >
              <input
                type="password"
                class="form-control is-valid"
                id="user-passe"
                v-model="passe"
                required
              />
              <!--alert-->
              <div class="invalid-feedback" style="font-size: 13px">
                Required !
              </div>
              <!--fin alert-->
            </div>

            <div class="mb">
              <label for="user-role" class="col-form-label logoo">Role :</label>

              <select
                class="form-select is-valid"
                aria-label="Default select example"
                id="user-role"
                v-model="selected"
                required
              >
                <option :value="{ role: 2 }" >Adminstrateur</option>
                <option :value="{ role: 3 }">Utilisateur</option>
              </select>
              <!--alert-->
              <div class="invalid-feedback" style="font-size: 13px">
                Required !
              </div>
              <!--fin alert-->
            </div>
            <div class="modal-footer logo">
              <button
                type="button"
                class="btn btn-danger"
                data-bs-dismiss="modal"
              >
                Close
              </button>
              <button
                type="button"
                class="btn btn-warning"
                @click="Notification()"
              >
                Ajouter
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import swal from "sweetalert2";
window.Swal = swal;
import axios from "axios";
export default {
  name: "AjouUser",
  data: () => {
    return {
      name: "",
      prenom: "",
      Email: "",
      passe: "",
      selected: "",
    };
  },
  methods: {
    AjouteUtilisteur(utilisateur) {
      this.$emit("AjouteUtilisteur", utilisateur);
    },
    Ajoutuser: function () {
      const user = {
        nom: this.name,
        prenom: this.prenom,
        email: this.Email,
        motdepasse: this.passe,
        idRole: this.selected.role,
      };
      axios
        .post("http://localhost:3000/api/Utilisateurs", user, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((res) => console.log(res))
        .catch((rer) => console.log(rer));
      this.AjouteUtilisteur(user);
    },
    Notification() {
      this.Ajoutuser();
      swal.fire("Ajouter!", "Your donation has been Ajouter.", "success");
    },
    reloadPage: function () {
      window.location.reload();
    },
  },
};
</script>
<style>
.logo {
  font-family: "Script MT";
  font-size: 30px;
  text-align: center;
  color: #888888;
}
.logo .logo-font {
  color: orange;
}
.logoo {
  font-family: "Script MT";
  font-size: 20px;
  text-align: center;
  color: orange;
}
</style>