<template>
  <div class="col-sm-8 logo">
   
 <div class="card">
   
      <div class="card-body">
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
          <button
            class="btn btn-warning"
            type="button"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
            data-bs-whatever="@getbootstrap"  style="border-radius: 20px"
          >
            <i class="bi bi-person-plus"></i> Crée niveau
          </button>
        </div>
        <br />
        <div class="col-sm" v-show="true">
          <div class="card h-100 rounded">
            <img
              src="../assets/admin.png"
              width="133px"
              style="margin-left: 41%"
              class="rounded-circle float-start"
              alt="..."
            />
            <div class="card-body">
              <small class="card-title"> {{ det.prenom }} {{ det.nom }}</small>
              <p class="card-tex">{{det.email}}</p>
            </div>
            <div class="card-footer rounded-circle">
              <small class="text-muted" v-if="det.idRole==2">Administrateur</small>
               <small class="text-muted" v-else>Utilisateur</small>
            </div>
          </div>
        </div>
      </div>
    </div>
    <br>
  </div>
</template>
<script>
export default {
  name: "DetailUser",
  props:["det"]
};
</script>