<template>


<!-- LOADING DOTS... -->
<div class="cont">
 
  <div class="pulse-container">  
    <div class="pulse-bubble pulse-bubble-1"></div>
    <div class="pulse-bubble pulse-bubble-2"></div>
    <div class="pulse-bubble pulse-bubble-3"></div>
    <div class="pulse-bubble pulse-bubble-4"></div>
     <div class="pulse-bubble pulse-bubble-4"></div>
  </div>
</div>
</template>
<script>
export default {
  name: "LoadingBare",
};
</script>

<style>


.cont{
  margin:340px;
 
}
.pulse-container {
  width: 200px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-left: 42%;
}

.pulse-bubble {
  width: 150px;
  height: 40px;
  border-radius: 50%;
  background-color: orange;
}

.pulse-bubble-1 {
    animation: pulse .8s ease 0s infinite alternate;
}
.pulse-bubble-2 {
    animation: pulse .8s ease .2s infinite alternate;
}
.pulse-bubble-3 {
    animation: pulse .8s ease .4s infinite alternate;
}
.pulse-bubble-4 {
    animation: pulse .8s ease .6s infinite alternate;
}
.pulse-bubble-4 {
    animation: pulse .8s ease .8s infinite alternate;
}
@keyframes pulse {
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: .4;
    transform: scale(.75);
  }
}

</style>