﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace GestionStagiaire.Models
{
    public partial class EtatStagiaire
    {
        public EtatStagiaire()
        {
            Stagiaire = new HashSet<Stagiaire>();
        }

        public int IdEtatStagiare { get; set; }
        public string EtatStagiaire1 { get; set; }

        public virtual ICollection<Stagiaire> Stagiaire { get; set; }
    }
}
