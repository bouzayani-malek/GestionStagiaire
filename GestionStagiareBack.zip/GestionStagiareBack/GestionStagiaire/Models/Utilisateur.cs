﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace GestionStagiaire.Models
{
    public partial class Utilisateur
    {
        public Utilisateur()
        {
            Commentaire = new HashSet<Commentaire>();
            SatgeUtilisateur = new HashSet<SatgeUtilisateur>();
            Stage = new HashSet<Stage>();
        }

        public int IdProprietaire { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Email { get; set; }
        public string Motdepasse { get; set; }
        public int IdRole { get; set; }

        public virtual Role IdRoleNavigation { get; set; }
        public virtual ICollection<Commentaire> Commentaire { get; set; }
        public virtual ICollection<SatgeUtilisateur> SatgeUtilisateur { get; set; }
        public virtual ICollection<Stage> Stage { get; set; }
    }
}
