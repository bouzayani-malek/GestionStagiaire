﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace GestionStagiaire.Models
{
    public partial class Commentaire
    {
        public string Commentaire1 { get; set; }
        public DateTime Date { get; set; }
        public int IdStagiaire { get; set; }
        public int IdProprietaire { get; set; }

        public virtual Utilisateur IdProprietaireNavigation { get; set; }
        public virtual Stagiaire IdStagiaireNavigation { get; set; }
    }
}
