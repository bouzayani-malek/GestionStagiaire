﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace GestionStagiaire.Models
{
    public partial class SatgeUtilisateur
    {
        public DateTime Date { get; set; }
        public int IdStage { get; set; }
        public int IdProprietaire { get; set; }

        public virtual Utilisateur IdProprietaireNavigation { get; set; }
        public virtual Stage IdStageNavigation { get; set; }
    }
}
