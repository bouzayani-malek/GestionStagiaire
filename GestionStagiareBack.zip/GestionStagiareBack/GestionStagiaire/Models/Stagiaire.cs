﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace GestionStagiaire.Models
{
    public partial class Stagiaire
    {
        public Stagiaire()
        {
            Commentaire = new HashSet<Commentaire>();
        }

        public int IdStagiaire { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Email { get; set; }
        public string Cv { get; set; }
        public int IdEtatStagiare { get; set; }
        public int IdStage { get; set; }

        public virtual EtatStagiaire IdEtatStagiareNavigation { get; set; }
        public virtual Stage IdStageNavigation { get; set; }
        public virtual ICollection<Commentaire> Commentaire { get; set; }
    }
}
