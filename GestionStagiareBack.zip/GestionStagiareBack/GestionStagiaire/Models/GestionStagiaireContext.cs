﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace GestionStagiaire.Models
{
    public partial class GestionStagiaireContext : DbContext
    {
        public GestionStagiaireContext()
        {
        }

        public GestionStagiaireContext(DbContextOptions<GestionStagiaireContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Commentaire> Commentaire { get; set; }
        public virtual DbSet<EtatStagiaire> EtatStagiaire { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<SatgeUtilisateur> SatgeUtilisateur { get; set; }
        public virtual DbSet<Stage> Stage { get; set; }
        public virtual DbSet<Stagiaire> Stagiaire { get; set; }
        public virtual DbSet<Utilisateur> Utilisateur { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=GestionStagiaire;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Commentaire>(entity =>
            {
                entity.HasKey(e => new { e.Date, e.IdStagiaire, e.IdProprietaire });

                entity.Property(e => e.Date)
                    .HasColumnName("date")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdStagiaire).HasColumnName("Id_stagiaire");

                entity.Property(e => e.IdProprietaire).HasColumnName("Id_proprietaire");

                entity.Property(e => e.Commentaire1)
                    .IsRequired()
                    .HasColumnName("commentaire")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdProprietaireNavigation)
                    .WithMany(p => p.Commentaire)
                    .HasForeignKey(d => d.IdProprietaire)
                    .HasConstraintName("FK_Commentaire_utilisateur");

                entity.HasOne(d => d.IdStagiaireNavigation)
                    .WithMany(p => p.Commentaire)
                    .HasForeignKey(d => d.IdStagiaire)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Commentaire_Stagiaire");
            });

            modelBuilder.Entity<EtatStagiaire>(entity =>
            {
                entity.HasKey(e => e.IdEtatStagiare);

                entity.ToTable("Etat-Stagiaire");

                entity.Property(e => e.IdEtatStagiare).HasColumnName("Id_etat_stagiare");

                entity.Property(e => e.EtatStagiaire1)
                    .IsRequired()
                    .HasColumnName("etat_stagiaire")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.IdRole)
                    .HasName("PK_Role_1");

                entity.Property(e => e.IdRole).HasColumnName("Id_role");

                entity.Property(e => e.Role1)
                    .IsRequired()
                    .HasColumnName("role")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SatgeUtilisateur>(entity =>
            {
                entity.HasKey(e => new { e.IdStage, e.IdProprietaire });

                entity.ToTable("Satge-Utilisateur");

                entity.Property(e => e.IdStage).HasColumnName("Id_stage");

                entity.Property(e => e.IdProprietaire).HasColumnName("Id_proprietaire");

                entity.Property(e => e.Date).HasColumnName("date");

                entity.HasOne(d => d.IdProprietaireNavigation)
                    .WithMany(p => p.SatgeUtilisateur)
                    .HasForeignKey(d => d.IdProprietaire)
                    .HasConstraintName("FK_Satge-Utilisateur_utilisateur");

                entity.HasOne(d => d.IdStageNavigation)
                    .WithMany(p => p.SatgeUtilisateur)
                    .HasForeignKey(d => d.IdStage)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Satge-Utilisateur_Stage");
            });

            modelBuilder.Entity<Stage>(entity =>
            {
                entity.HasKey(e => e.IdStage);

                entity.Property(e => e.IdStage).HasColumnName("Id_stage");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("description")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Etat).HasColumnName("etat");

                entity.Property(e => e.IdProprietaire).HasColumnName("Id_proprietaire");

                entity.Property(e => e.Image)
                    .IsRequired()
                    .HasColumnName("image")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NombreStagiaire).HasColumnName("nombre_stagiaire");

                entity.Property(e => e.Titre)
                    .IsRequired()
                    .HasColumnName("titre")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdProprietaireNavigation)
                    .WithMany(p => p.Stage)
                    .HasForeignKey(d => d.IdProprietaire)
                    .HasConstraintName("FK_Stage_utilisateur");
            });

            modelBuilder.Entity<Stagiaire>(entity =>
            {
                entity.HasKey(e => e.IdStagiaire);

                entity.Property(e => e.IdStagiaire).HasColumnName("Id_stagiaire");

                entity.Property(e => e.Cv)
                    .IsRequired()
                    .HasColumnName("cv")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IdEtatStagiare).HasColumnName("Id_etat_stagiare");

                entity.Property(e => e.IdStage).HasColumnName("Id_stage");

                entity.Property(e => e.Nom)
                    .IsRequired()
                    .HasColumnName("nom")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Prenom)
                    .IsRequired()
                    .HasColumnName("prenom")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdEtatStagiareNavigation)
                    .WithMany(p => p.Stagiaire)
                    .HasForeignKey(d => d.IdEtatStagiare)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Stagiaire_Etat-Stagiaire");

                entity.HasOne(d => d.IdStageNavigation)
                    .WithMany(p => p.Stagiaire)
                    .HasForeignKey(d => d.IdStage)
                    .HasConstraintName("FK_Stagiaire_Stage");
            });

            modelBuilder.Entity<Utilisateur>(entity =>
            {
                entity.HasKey(e => e.IdProprietaire)
                    .HasName("PK__utilisat__3214EC0707A8C89A");

                entity.ToTable("utilisateur");

                entity.Property(e => e.IdProprietaire).HasColumnName("Id_proprietaire");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(20);

                entity.Property(e => e.IdRole).HasColumnName("Id_role");

                entity.Property(e => e.Motdepasse)
                    .IsRequired()
                    .HasColumnName("motdepasse")
                    .HasMaxLength(50);

                entity.Property(e => e.Nom)
                    .IsRequired()
                    .HasColumnName("nom")
                    .HasMaxLength(50);

                entity.Property(e => e.Prenom)
                    .IsRequired()
                    .HasColumnName("prenom")
                    .HasMaxLength(50);

                entity.HasOne(d => d.IdRoleNavigation)
                    .WithMany(p => p.Utilisateur)
                    .HasForeignKey(d => d.IdRole)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_utilisateur_Role1");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
