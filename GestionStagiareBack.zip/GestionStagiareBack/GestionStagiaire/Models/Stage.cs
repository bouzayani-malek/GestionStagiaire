﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace GestionStagiaire.Models
{
    public partial class Stage
    {
        public Stage()
        {
            SatgeUtilisateur = new HashSet<SatgeUtilisateur>();
            Stagiaire = new HashSet<Stagiaire>();
        }

        public int IdStage { get; set; }
        public string Titre { get; set; }
        public string Description { get; set; }
        public int NombreStagiaire { get; set; }
        public string Image { get; set; }
        public int Etat { get; set; }
        public int IdProprietaire { get; set; }

        public virtual Utilisateur IdProprietaireNavigation { get; set; }
        public virtual ICollection<SatgeUtilisateur> SatgeUtilisateur { get; set; }
        public virtual ICollection<Stagiaire> Stagiaire { get; set; }
    }
}
