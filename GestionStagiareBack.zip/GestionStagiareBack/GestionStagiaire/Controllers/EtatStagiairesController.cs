﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionStagiaire.Models;
using Microsoft.AspNetCore.Authorization;

namespace GestionStagiaire.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EtatStagiairesController : ControllerBase
    {
        private readonly GestionStagiaireContext _context;

        public EtatStagiairesController(GestionStagiaireContext context)
        {
            _context = context;
        }

        // GET: api/EtatStagiaires
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EtatStagiaire>>> GetEtatStagiaire()
        {

            List<EtatStagiaire> etatStagiaire = _context.EtatStagiaire.ToList();
            foreach (EtatStagiaire Stagiaire in etatStagiaire)
            {
                _context.Entry(Stagiaire)
                        .Collection(s => s.Stagiaire)
                        .Query()
                        .Include(s => s.Commentaire)
                        .Load();
            }
            return etatStagiaire;
           // return await _context.EtatStagiaire.ToListAsync();
        }

        // GET: api/EtatStagiaires/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EtatStagiaire>> GetEtatStagiaire(int id)
        {
            var etatStagiaire = await _context.EtatStagiaire.FindAsync(id);
            _context.Entry(etatStagiaire)
                    .Collection(stage => stage.Stagiaire)
                    .Query()
                    .Include(stage => stage.Commentaire)
                    .Load();
        
            if (etatStagiaire == null)
            {
                return NotFound();
            }

            return etatStagiaire;
        }

        // PUT: api/EtatStagiaires/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEtatStagiaire(int id, EtatStagiaire etatStagiaire)
        {
            if (id != etatStagiaire.IdEtatStagiare)
            {
                return BadRequest();
            }

            _context.Entry(etatStagiaire).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EtatStagiaireExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EtatStagiaires
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<EtatStagiaire>> PostEtatStagiaire(EtatStagiaire etatStagiaire)
        {
            _context.EtatStagiaire.Add(etatStagiaire);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEtatStagiaire", new { id = etatStagiaire.IdEtatStagiare }, etatStagiaire);
        }

        // DELETE: api/EtatStagiaires/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EtatStagiaire>> DeleteEtatStagiaire(int id)
        {
            var etatStagiaire = await _context.EtatStagiaire.FindAsync(id);
            if (etatStagiaire == null)
            {
                return NotFound();
            }

            _context.EtatStagiaire.Remove(etatStagiaire);
            await _context.SaveChangesAsync();

            return etatStagiaire;
        }

        private bool EtatStagiaireExists(int id)
        {
            return _context.EtatStagiaire.Any(e => e.IdEtatStagiare == id);
        }
    }
}
