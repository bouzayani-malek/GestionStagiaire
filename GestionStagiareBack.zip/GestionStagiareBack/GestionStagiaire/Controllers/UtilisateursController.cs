﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionStagiaire.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;

namespace GestionStagiaire.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UtilisateursController : ControllerBase
    {
        private IConfiguration _config;
        private readonly GestionStagiaireContext _context;

        public UtilisateursController(GestionStagiaireContext context, IConfiguration config)
        {
            _config = config;
            _context = context;
        }
        //authentification *******************************
        [AllowAnonymous]
        [HttpPost("login")]
        public ActionResult<Utilisateur> CreateToken( Utilisateur login)
        {
            if (login == null) return Unauthorized();
            string tokenString = string.Empty;

            Utilisateur validUser = Authenticate(login);
            if (validUser !=null)
            {
                tokenString = BuildJWTToken();
            }
            else
            {
                return Unauthorized();
            }
            return Ok(new { Token = tokenString, validUser });
        }

        private string BuildJWTToken()
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["JwtToken:SecretKey"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var issuer = _config["JwtToken:Issuer"];
            var audience = _config["JwtToken:Audience"];
            var jwtValidity = DateTime.Now.AddMinutes(Convert.ToDouble(_config["JwtToken:TokenExpiry"]));

            var token = new JwtSecurityToken(issuer,
              audience,
              expires: jwtValidity,
              signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private Utilisateur Authenticate(Utilisateur login)
        {
            Utilisateur validUser = null;
            List<Utilisateur> utilisateurs = _context.Utilisateur.ToList();
            foreach (Utilisateur utilisateur in utilisateurs)
            {
                if ((utilisateur.Nom == login.Nom)&&(utilisateur.Motdepasse==login.Motdepasse))
                {
                    validUser = utilisateur;
                }
            }
               
            return validUser;

        }
    




    //authentification *******************************
    // GET: api/Utilisateurs
    [HttpGet]
        public async Task<ActionResult<IEnumerable<Utilisateur>>> GetUtilisateurs()
        {

            List<Utilisateur> utilisateurs = _context.Utilisateur.ToList();
            foreach (Utilisateur utilisateur in utilisateurs)
            {
                _context.Entry(utilisateur)
               .Collection(u => u.Commentaire)
               .Load();
                _context.Entry(utilisateur)
                   .Collection(u => u.SatgeUtilisateur)
                   .Load();
                _context.Entry(utilisateur)
                   .Collection(u => u.Stage)
                   .Query()
                   .Include(s => s.Stagiaire)
                   .Load();
            }
            return utilisateurs;
            // return await _context.Utilisateur.ToListAsync();
        }

        // GET: api/Utilisateurs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Utilisateur>> GetUtilisateur(int id)
        {
            // var utilisateur = await _context.Utilisateur.FindAsync(id);
            //insertion des stages, Commentaires et satgeUtilisatreurs 
            var utilisateur = await _context.Utilisateur.SingleAsync(user => user.IdProprietaire==id);
            _context.Entry(utilisateur)
                .Collection(u => u.Commentaire)
                .Load();
            _context.Entry(utilisateur)
               .Collection(u => u.SatgeUtilisateur)
               .Load();
            _context.Entry(utilisateur)
               .Collection(u => u.Stage)
               .Query()
               .Include(s=>s.Stagiaire)
               .Load();

            /////////////s

            if (utilisateur == null)
            {
                return NotFound("NotFound");
            }

            return utilisateur;
        }

        // PUT: api/Utilisateurs/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUtilisateur(int id, Utilisateur utilisateur)
        {
            if (id != utilisateur.IdProprietaire)
            {
                return BadRequest();
            }

            _context.Entry(utilisateur).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UtilisateurExists(id))
                {
                    return NotFound("NotFound");
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Utilisateurs
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Utilisateur>> PostUtilisateur(Utilisateur utilisateur)
        {
            _context.Utilisateur.Add(utilisateur);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUtilisateur", new { id = utilisateur.IdProprietaire }, utilisateur);
        }

        // DELETE: api/Utilisateurs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Utilisateur>> DeleteUtilisateur(int id)
        {
            var utilisateur = await _context.Utilisateur.FindAsync(id);
            if (utilisateur == null)
            {
                return NotFound("NotFound");
            }

            _context.Utilisateur.Remove(utilisateur);
            await _context.SaveChangesAsync();

            return utilisateur;
        }

        private bool UtilisateurExists(int id)
        {
            return _context.Utilisateur.Any(e => e.IdProprietaire == id);
        }
    }
}
