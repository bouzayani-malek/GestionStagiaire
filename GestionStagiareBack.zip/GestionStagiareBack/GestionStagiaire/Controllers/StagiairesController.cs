﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionStagiaire.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting.Internal;

namespace GestionStagiaire.Controllers
{
   // [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StagiairesController : ControllerBase
    {
        private IConfiguration _config;
        private readonly GestionStagiaireContext _context;

        public IHostingEnvironment hostingEnvironement;

        public StagiairesController(GestionStagiaireContext context, IConfiguration config ,IHostingEnvironment hosting)
        {
            _config = config;
            _context = context;
            hostingEnvironement = hosting;
        }



        //authentification *******************************
        [AllowAnonymous]
        [HttpPost("DemandeStagiaire")]
        public async Task<ActionResult<Stagiaire>> PostStagiaires(Stagiaire stagiaire)
        {

            var files = HttpContext.Request.Form.Files;
            if (files != null && files.Count > 0)
            {
                foreach (var file in files)
                {
                    FileInfo fi = new FileInfo(file.FileName);
                    var newfilename = "image_" + DateTime.Now.TimeOfDay.Milliseconds + fi.Extension;
                    var path = Path.Combine("", hostingEnvironement.ContentRootPath + "/Cvs/" + newfilename);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }
            }



            // _context.Stagiaire.Add(stagiaire);
            //   await _context.SaveChangesAsync();
            // return CreatedAtAction("GetStagiaire", new { id = stagiaire.IdStagiaire }, stagiaire);

            return Ok("bien");
            // return Ok(new { Token = "ok"});
        }

        //*******************************ajouter file to serveur*************************
        public ActionResult<String> ajouter()
        {

            var files = HttpContext.Request.Form.Files;
            if (files != null && files.Count > 0)
            {
                foreach (var file in files)
                {
                    FileInfo fi = new FileInfo(file.FileName);
                    var newfilename = "image_" + DateTime.Now.TimeOfDay.Milliseconds + fi.Extension;
                    var path = Path.Combine("", hostingEnvironement.ContentRootPath + "/Cvs/" + newfilename);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }
            }



            // _context.Stagiaire.Add(stagiaire);
            //   await _context.SaveChangesAsync();
            // return CreatedAtAction("GetStagiaire", new { id = stagiaire.IdStagiaire }, stagiaire);

            //  return newfilename;
            return "yes";
        }
        //**************************************fin de l'ajouter******************************







        //authentification *******************************

        // GET: api/Stagiaires
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Stagiaire>>> GetStagiaire()
        {

            List<Stagiaire> stagiaires = _context.Stagiaire.ToList();
            foreach (Stagiaire stagiaire in stagiaires)
            {
                _context.Entry(stagiaire)
                     .Collection(sta => sta.Commentaire)
                     .Load();
            }
            return stagiaires;
            // return await _context.Stagiaire.ToListAsync();
        }

        // GET: api/Stagiaires/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Stagiaire>> GetStagiaire(int id)
        {
            var stagiaire = await _context.Stagiaire.FindAsync(id);
            _context.Entry(stagiaire)
                    .Collection(sta => sta.Commentaire)
                    .Load();

            if (stagiaire == null)
            {
                return NotFound();
            }

            return stagiaire;
        }

        // PUT: api/Stagiaires/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStagiaire(int id, Stagiaire stagiaire)
        {
            if (id != stagiaire.IdStagiaire)
            {
                return BadRequest();
            }

            _context.Entry(stagiaire).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StagiaireExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Stagiaires
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Stagiaire>> PostStagiaire(Stagiaire stagiaire)
        {
            _context.Stagiaire.Add(stagiaire);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStagiaire", new { id = stagiaire.IdStagiaire }, stagiaire);
        }

        // DELETE: api/Stagiaires/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Stagiaire>> DeleteStagiaire(int id)
        {
            var stagiaire = await _context.Stagiaire.FindAsync(id);
            if (stagiaire == null)
            {
                return NotFound();
            }

            _context.Stagiaire.Remove(stagiaire);
            await _context.SaveChangesAsync();

            return stagiaire;
        }

        private bool StagiaireExists(int id)
        {
            return _context.Stagiaire.Any(e => e.IdStagiaire == id);
        }
    }
}
