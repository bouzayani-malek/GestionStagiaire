﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionStagiaire.Models;
using Microsoft.AspNetCore.Authorization;

namespace GestionStagiaire.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SatgeUtilisateursController : ControllerBase
    {
        private readonly GestionStagiaireContext _context;

        public SatgeUtilisateursController(GestionStagiaireContext context)
        {
            _context = context;
        }

        // GET: api/SatgeUtilisateurs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<SatgeUtilisateur>>> GetSatgeUtilisateur()
        {
            return await _context.SatgeUtilisateur.ToListAsync();
        }

        // GET: api/SatgeUtilisateurs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<SatgeUtilisateur>> GetSatgeUtilisateur(int id)
        {
            var satgeUtilisateur = await _context.SatgeUtilisateur.FindAsync(id);

            if (satgeUtilisateur == null)
            {
                return NotFound();
            }

            return satgeUtilisateur;
        }

        // PUT: api/SatgeUtilisateurs/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSatgeUtilisateur(int id, SatgeUtilisateur satgeUtilisateur)
        {
            if (id != satgeUtilisateur.IdStage)
            {
                return BadRequest();
            }

            _context.Entry(satgeUtilisateur).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SatgeUtilisateurExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/SatgeUtilisateurs
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<SatgeUtilisateur>> PostSatgeUtilisateur(SatgeUtilisateur satgeUtilisateur)
        {
            _context.SatgeUtilisateur.Add(satgeUtilisateur);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (SatgeUtilisateurExists(satgeUtilisateur.IdStage))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetSatgeUtilisateur", new { id = satgeUtilisateur.IdStage }, satgeUtilisateur);
        }

        // DELETE: api/SatgeUtilisateurs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<SatgeUtilisateur>> DeleteSatgeUtilisateur(int id)
        {
            var satgeUtilisateur = await _context.SatgeUtilisateur.FindAsync(id);
            if (satgeUtilisateur == null)
            {
                return NotFound();
            }

            _context.SatgeUtilisateur.Remove(satgeUtilisateur);
            await _context.SaveChangesAsync();

            return satgeUtilisateur;
        }

        private bool SatgeUtilisateurExists(int id)
        {
            return _context.SatgeUtilisateur.Any(e => e.IdStage == id);
        }
    }
}
