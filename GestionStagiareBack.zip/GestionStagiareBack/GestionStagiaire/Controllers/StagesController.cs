﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionStagiaire.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace GestionStagiaire.Controllers
{
   // [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StagesController : ControllerBase
    {

        private IConfiguration _config;
        private readonly GestionStagiaireContext _context;

        public StagesController(GestionStagiaireContext context, IConfiguration config)
        {
            _config = config;
            _context = context;
        }

        //authentification *******************************
        [AllowAnonymous]
        [HttpGet("DemandeStagiaire")]
        public ActionResult<Stage> CreateToken(int code)
        {
            if (code == null) return Unauthorized();
           

            Stage validUser = recherche(code);
            if (validUser != null)
            {
                return Ok(new { validUser });
            }
            else
            {
                return Unauthorized();
            }
         
        }

       

        private Stage recherche(int login)
        {
        Stage validUser = null;
            List<Stage> Stages = _context.Stage.ToList();
            foreach (Stage stage in Stages)
            {
                if ((stage.IdStage == login)&& (stage.Etat==1)) 
                {
                    validUser = stage;
                  
                    
                }
            }

            return validUser;

        }





        //authentification *******************************


        // GET: api/Stages
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Stage>>> GetStage()
        {
            List<Stage> stages=  _context.Stage.ToList();
            foreach(Stage s in stages)
            {
                _context.Entry(s)
                        .Collection(s => s.Stagiaire)
                        .Query()
                        .Include(s=>s.Commentaire)
                        .Load();
                _context.Entry(s)
                      .Collection(s => s.SatgeUtilisateur)

                      .Load();
            }
            return stages;

            //return await _context.Stage.ToListAsync();
        }

        // GET: api/Stages/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Stage>> GetStage(int id)
        {
            //   var stage = await _context.Stage.FindAsync(id);
            var stage = await _context.Stage.SingleAsync(stage => stage.IdStage == id);
            _context.Entry(stage)
                    .Collection(stage => stage.Stagiaire)
                    .Query()
                    .Include(stage=>stage.Commentaire)
                    .Load();
            _context.Entry(stage)
                  .Collection(stage => stage.SatgeUtilisateur)
                  .Load();

            if (stage == null)
            {
                return NotFound();
            }

            return stage;
        }

        // PUT: api/Stages/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStage(int id, Stage stage)
        {
            if (id != stage.IdStage)
            {
                return BadRequest();
            }

            _context.Entry(stage).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StageExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Stages
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Stage>> PostStage(Stage stage)
        {
            _context.Stage.Add(stage);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStage", new { id = stage.IdStage }, stage);
        }

        // DELETE: api/Stages/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Stage>> DeleteStage(int id)
        {
            var stage = await _context.Stage.FindAsync(id);
            if (stage == null)
            {
                return NotFound();
            }

            _context.Stage.Remove(stage);
            await _context.SaveChangesAsync();

            return stage;
        }

        private bool StageExists(int id)
        {
            return _context.Stage.Any(e => e.IdStage == id);
        }
    }
}
